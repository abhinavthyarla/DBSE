# Smart Event - Android Mobile Application

This directory contains the native Android project that connects directly with your FastAPI backend.

---

## Architecture

```
Android App (WebView / REST Native Shell)
              │
              ▼  (HTTP / JSON / JWT)
   FastAPI Server (`http://10.0.2.2:8000`)
              │
              ▼  (SQLAlchemy)
       PostgreSQL / SQLite
```

- **Android Emulator Address**: In Android emulators, `10.0.2.2` automatically routes to your host machine's `localhost`. The app is pre-configured to load `http://10.0.2.2:8000`.
- **Physical Android Phone**: To test on a real Android phone connected via USB or WiFi, open `MainActivity.java` and change `APP_URL` to your machine's local WiFi IP (e.g. `http://192.168.1.15:8000`).

---

## How to Run in Android Studio

1. **Start the FastAPI Backend**:
   ```bash
   cd backend
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```
2. **Open Android Studio**:
   - Choose **Open an Existing Project**.
   - Navigate to the `android/` directory inside this project and click **OK**.
3. **Gradle Sync**:
   - Android Studio will automatically resolve Gradle dependencies (`androidx.appcompat`, `swiperefreshlayout`, `webkit`).
4. **Run on Emulator or Device**:
   - Select your virtual device (e.g. Pixel 8 / API 34) or connected physical Android phone.
   - Click the green **Run (▶)** button (Shift + F10).
5. **Build Signed / Debug APK**:
   - In Android Studio menu: **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.

---

## Alternative: Zero-Install Progressive Web App (PWA)

If you do not want to install Android Studio:
1. Start the FastAPI backend:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```
2. Open Chrome on your Android smartphone and navigate to `http://<your-pc-ip>:8000`.
3. Tap the **Install Smart Event** banner or Chrome menu `⋮` > **Add to Home screen** / **Install App**.
4. The app installs as a native Android WebAPK with full-screen standalone experience, home screen icon, and offline asset caching!
