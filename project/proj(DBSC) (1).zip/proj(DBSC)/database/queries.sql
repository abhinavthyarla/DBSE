-- ==========================================================
-- SMART EVENT MANAGEMENT & BOOKING SYSTEM (DBSE PROJECT)
-- File: queries.sql (Viva & Lab Showcase SQL Queries)
-- ==========================================================

-- 1. BASIC SELECT & FILTERING (Upcoming Active Events)
SELECT event_id, title, event_date, start_time, end_time, status
FROM events
WHERE event_date >= CURRENT_DATE AND status = 'ACTIVE'
ORDER BY event_date ASC;

-- 2. MULTI-TABLE INNER JOIN (Event details with Category and Venue)
SELECT 
    e.title AS event_name,
    c.name AS category,
    v.name AS venue_name,
    v.city,
    v.capacity,
    e.event_date
FROM events e
INNER JOIN categories c ON e.category_id = c.category_id
INNER JOIN venues v ON e.venue_id = v.venue_id
WHERE v.city = 'Bengaluru';

-- 3. LEFT OUTER JOIN (All Ticket Tiers per Event with Availability)
SELECT 
    e.title,
    tt.name AS tier_name,
    tt.price,
    tt.available_quantity,
    tt.total_quantity,
    ROUND(((tt.total_quantity - tt.available_quantity)::numeric / tt.total_quantity) * 100, 2) AS percent_sold
FROM events e
LEFT JOIN ticket_types tt ON e.event_id = tt.event_id
ORDER BY e.event_id, tt.price ASC;

-- 4. AGGREGATE FUNCTION WITH GROUP BY & HAVING (Venues hosting more than 1 event)
SELECT 
    v.name AS venue_name,
    v.city,
    COUNT(e.event_id) AS total_events_hosted
FROM venues v
JOIN events e ON v.venue_id = e.venue_id
GROUP BY v.venue_id, v.name, v.city
HAVING COUNT(e.event_id) >= 1
ORDER BY total_events_hosted DESC;

-- 5. TOTAL SYSTEM REVENUE (Aggregates on confirmed bookings)
SELECT 
    COUNT(b.booking_id) AS total_successful_bookings,
    SUM(b.total_amount) AS gross_revenue,
    AVG(b.total_amount) AS average_order_value,
    MIN(b.total_amount) AS smallest_booking,
    MAX(b.total_amount) AS largest_booking
FROM bookings b
WHERE b.booking_status = 'CONFIRMED';

-- 6. SUBQUERY: Find users who booked tickets for 'Technology' events
SELECT full_name, email, phone
FROM users
WHERE user_id IN (
    SELECT DISTINCT b.user_id
    FROM bookings b
    JOIN booking_details bd ON b.booking_id = bd.booking_id
    JOIN ticket_types tt ON bd.ticket_id = tt.ticket_id
    JOIN events e ON tt.event_id = e.event_id
    JOIN categories c ON e.category_id = c.category_id
    WHERE c.name = 'Technology'
);

-- 7. CORRELATED SUBQUERY: Events that have higher than average ticket prices
SELECT e.title, tt.name, tt.price
FROM ticket_types tt
JOIN events e ON tt.event_id = e.event_id
WHERE tt.price > (
    SELECT AVG(price) 
    FROM ticket_types
);

-- 8. VIVA TRANSACTION DEMO (ACID Atomic Booking Execution)
-- This block demonstrates PostgreSQL ACID compliance:
BEGIN;

-- Step A: Insert Booking
INSERT INTO bookings (booking_id, booking_ref, user_id, total_amount, booking_status)
VALUES (999, 'BK-TEST-TXN', 3, 1499.00, 'CONFIRMED');

-- Step B: Insert Booking Line Item
INSERT INTO booking_details (detail_id, booking_id, ticket_id, quantity, unit_price, subtotal)
VALUES (999, 999, 2, 1, 1499.00, 1499.00);

-- Step C: Record Payment
INSERT INTO payments (payment_id, booking_id, payment_method, amount, payment_status, transaction_id)
VALUES (999, 999, 'UPI', 1499.00, 'SUCCESS', 'TXN-DEMO-ACID-01');

-- If any step fails: ROLLBACK;
-- Otherwise:
COMMIT;
