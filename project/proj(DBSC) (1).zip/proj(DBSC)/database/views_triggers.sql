-- ==========================================================
-- SMART EVENT MANAGEMENT & BOOKING SYSTEM (DBSE PROJECT)
-- File: views_triggers.sql (Advanced SQL: Views & Triggers)
-- ==========================================================

-- ==========================================================
-- SECTION 1: DATABASE VIEWS
-- ==========================================================

-- VIEW 1: Event Sales and Revenue Overview
-- Aggregates total tickets sold and revenue per event
CREATE OR REPLACE VIEW event_sales_view AS
SELECT 
    e.event_id,
    e.title AS event_title,
    c.name AS category_name,
    v.name AS venue_name,
    e.event_date,
    COALESCE(SUM(bd.quantity), 0) AS total_tickets_sold,
    COALESCE(SUM(bd.subtotal), 0.00) AS gross_revenue
FROM events e
JOIN categories c ON e.category_id = c.category_id
JOIN venues v ON e.venue_id = v.venue_id
LEFT JOIN ticket_types tt ON e.event_id = tt.event_id
LEFT JOIN booking_details bd ON tt.ticket_id = bd.ticket_id
LEFT JOIN bookings b ON bd.booking_id = b.booking_id AND b.booking_status = 'CONFIRMED'
GROUP BY e.event_id, e.title, c.name, v.name, e.event_date;

-- VIEW 2: User Booking Summary
-- Shows each user's booking history metrics
CREATE OR REPLACE VIEW user_booking_summary_view AS
SELECT 
    u.user_id,
    u.full_name,
    u.email,
    COUNT(DISTINCT b.booking_id) AS total_bookings,
    COALESCE(SUM(b.total_amount), 0.00) AS total_spent
FROM users u
LEFT JOIN bookings b ON u.user_id = b.user_id AND b.booking_status = 'CONFIRMED'
GROUP BY u.user_id, u.full_name, u.email;

-- VIEW 3: Popular Events Ranking
-- Displays events ranked by popularity / bookings count
CREATE OR REPLACE VIEW popular_events_view AS
SELECT 
    e.event_id,
    e.title,
    c.name AS category,
    COUNT(DISTINCT b.booking_id) AS total_orders,
    COALESCE(AVG(r.rating), 0.0) AS average_rating,
    COUNT(r.review_id) AS review_count
FROM events e
JOIN categories c ON e.category_id = c.category_id
LEFT JOIN ticket_types tt ON e.event_id = tt.event_id
LEFT JOIN booking_details bd ON tt.ticket_id = bd.ticket_id
LEFT JOIN bookings b ON bd.booking_id = b.booking_id AND b.booking_status = 'CONFIRMED'
LEFT JOIN reviews r ON e.event_id = r.event_id
GROUP BY e.event_id, e.title, c.name
ORDER BY total_orders DESC;


-- ==========================================================
-- SECTION 2: PL/pgSQL TRIGGERS
-- ==========================================================

-- TRIGGER 1: Decrement Available Tickets on Booking
-- Automatically reduces available tickets and ensures no overbooking
CREATE OR REPLACE FUNCTION fn_decrement_available_tickets()
RETURNS TRIGGER AS $$
DECLARE
    current_avail INTEGER;
BEGIN
    SELECT available_quantity INTO current_avail
    FROM ticket_types
    WHERE ticket_id = NEW.ticket_id
    FOR UPDATE;

    IF current_avail < NEW.quantity THEN
        RAISE EXCEPTION 'Insufficient tickets available! Requested %, Available %', 
            NEW.quantity, current_avail;
    END IF;

    UPDATE ticket_types
    SET available_quantity = available_quantity - NEW.quantity
    WHERE ticket_id = NEW.ticket_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_decrement_tickets ON booking_details;
CREATE TRIGGER trg_decrement_tickets
AFTER INSERT ON booking_details
FOR EACH ROW
EXECUTE FUNCTION fn_decrement_available_tickets();


-- TRIGGER 2: Restore Available Tickets on Booking Cancellation
-- Restores tickets back to pool if booking is cancelled
CREATE OR REPLACE FUNCTION fn_restore_tickets_on_cancel()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.booking_status <> 'CANCELLED' AND NEW.booking_status = 'CANCELLED' THEN
        UPDATE ticket_types tt
        SET available_quantity = tt.available_quantity + bd.quantity
        FROM booking_details bd
        WHERE bd.booking_id = NEW.booking_id
          AND bd.ticket_id = tt.ticket_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_restore_tickets ON bookings;
CREATE TRIGGER trg_restore_tickets
AFTER UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION fn_restore_tickets_on_cancel();
