-- ==========================================================
-- SMART EVENT MANAGEMENT & BOOKING SYSTEM (DBSE PROJECT)
-- File: seed.sql (Comprehensive Mock Data for Viva/Testing)
-- Passwords for mock users are bcrypt hashed for "password123":
-- $2b$12$e8x5uU8uQ51LwR71gZk0xeZ27E9F45N1a2Qk68/V4L8M8Z3pA3d3u
-- ==========================================================

-- 1. USERS (Admin, Organizer, Attendees)
INSERT INTO users (user_id, full_name, email, password_hash, phone, role) VALUES
(1, 'System Administrator', 'admin@smartevent.com', '$2b$12$K1rS2B5QOcb8zX2q2n8NmeYkQZpP/Y21r6JtE718V6s4Qf51JpE8.', '9876543210', 'ADMIN'),
(2, 'Alex Organizer', 'alex@eventpulse.io', '$2b$12$K1rS2B5QOcb8zX2q2n8NmeYkQZpP/Y21r6JtE718V6s4Qf51JpE8.', '9876543211', 'ORGANIZER'),
(3, 'Aman Sharma', 'aman@gmail.com', '$2b$12$K1rS2B5QOcb8zX2q2n8NmeYkQZpP/Y21r6JtE718V6s4Qf51JpE8.', '9876543212', 'USER'),
(4, 'Abhinav Patel', 'abhinav@gmail.com', '$2b$12$K1rS2B5QOcb8zX2q2n8NmeYkQZpP/Y21r6JtE718V6s4Qf51JpE8.', '9876543213', 'USER'),
(5, 'Ashish Kumar', 'ashish@gmail.com', '$2b$12$K1rS2B5QOcb8zX2q2n8NmeYkQZpP/Y21r6JtE718V6s4Qf51JpE8.', '9876543214', 'USER');

SELECT setval('users_user_id_seq', 5, true);

-- 2. CATEGORIES
INSERT INTO categories (category_id, name, description, icon_name) VALUES
(1, 'Technology', 'Conferences, Hackathons, AI Summits, Developer meetups', 'cpu'),
(2, 'Music & Concerts', 'Live concerts, acoustic nights, EDM festivals, indie jams', 'music'),
(3, 'Business & Startups', 'Pitch competitions, investor summits, entrepreneurship workshops', 'briefcase'),
(4, 'Sports & Fitness', 'Marathons, football championships, yoga retreats, esports tournaments', 'activity'),
(5, 'Arts & Culture', 'Art exhibitions, theater plays, standup comedy, literature festivals', 'palette');

SELECT setval('categories_category_id_seq', 5, true);

-- 3. VENUES
INSERT INTO venues (venue_id, name, address, city, state, capacity) VALUES
(1, 'Grand Tech Convention Center', '120 Ring Road, Electronic City', 'Bengaluru', 'Karnataka', 2500),
(2, 'Royal Symphony Amphitheater', '45 Marine Lines, Nariman Point', 'Mumbai', 'Maharashtra', 3500),
(3, 'National Innovation Arena', 'Barakhamba Road, Connaught Place', 'New Delhi', 'Delhi', 1800),
(4, 'Cyber Hub Auditorium', 'DLF Phase 2, Sector 24', 'Gurugram', 'Haryana', 950),
(5, 'Marina Bay Open Grounds', 'Kamarajar Promenade, Triplicane', 'Chennai', 'Tamil Nadu', 5000);

SELECT setval('venues_venue_id_seq', 5, true);

-- 4. EVENTS
INSERT INTO events (event_id, title, description, category_id, venue_id, organizer_id, banner_url, event_date, start_time, end_time, status) VALUES
(1, 'NextGen AI & Cloud Summit 2026', 'A premier global conference bringing together leading AI researchers, cloud architects, and tech innovators for keynote sessions and hands-on workshops.', 1, 1, 2, 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200', '2026-10-15', '09:30:00', '17:30:00', 'ACTIVE'),
(2, 'Electric Moonlight Music Festival', 'Experience an electrifying night of live indie music, psychedelic visual projections, and food trucks with top artists.', 2, 2, 2, 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200', '2026-10-24', '18:00:00', '23:30:00', 'ACTIVE'),
(3, 'SeedStage Startup Workshop & Pitch', 'Connect with angel investors, learn product-market fit strategies, and pitch your startup for seed funding.', 3, 4, 2, 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=1200', '2026-11-05', '10:00:00', '16:00:00', 'ACTIVE'),
(4, 'National Corporate Esports Championship', 'High-octane esports tournament featuring League of Legends, Valorant, and Rocket League with a prize pool of 5 Lakhs.', 4, 3, 2, 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200', '2026-11-12', '11:00:00', '20:00:00', 'ACTIVE'),
(5, 'Midnight Comedy & Improv Night', 'An uncensored evening of belly-laughing standup comedy, sketches, and audience improv by national award-winning comics.', 5, 4, 2, 'https://images.unsplash.com/photo-1585699324551-f6c309eedeca?w=1200', '2026-11-20', '19:30:00', '22:00:00', 'ACTIVE');

SELECT setval('events_event_id_seq', 5, true);

-- 5. TICKET TYPES (Regular, Premium, VIP)
INSERT INTO ticket_types (ticket_id, event_id, name, price, total_quantity, available_quantity) VALUES
-- Event 1: AI Summit
(1, 1, 'Regular Attendee', 799.00, 300, 290),
(2, 1, 'Premium Workshop Access', 1499.00, 150, 142),
(3, 1, 'VIP All-Access + Dinner', 2999.00, 50, 48),

-- Event 2: Music Festival
(4, 2, 'General Standing', 599.00, 500, 485),
(5, 2, 'Fan Pit (Front Stage)', 1299.00, 200, 192),
(6, 2, 'VIP Lounge & Drinks', 2499.00, 80, 75),

-- Event 3: Startup Workshop
(7, 3, 'Founder Pass', 499.00, 100, 95),
(8, 3, 'Investor & VIP Pass', 1999.00, 30, 28),

-- Event 4: Esports Championship
(9, 4, 'Spectator Pass', 299.00, 400, 390),
(10, 4, 'Pro Gamer Pit Access', 899.00, 100, 96),

-- Event 5: Comedy Night
(11, 5, 'Silver Balcony', 399.00, 150, 145),
(12, 5, 'Gold Front Row', 799.00, 75, 70);

SELECT setval('ticket_types_ticket_id_seq', 12, true);

-- 6. BOOKINGS
INSERT INTO bookings (booking_id, booking_ref, user_id, total_amount, booking_status, booking_date) VALUES
(1, 'BK-2026-1001', 3, 2298.00, 'CONFIRMED', '2026-09-10 14:20:00'),
(2, 'BK-2026-1002', 4, 1299.00, 'CONFIRMED', '2026-09-11 16:45:00'),
(3, 'BK-2026-1003', 5, 2999.00, 'CONFIRMED', '2026-09-12 11:10:00');

SELECT setval('bookings_booking_id_seq', 3, true);

-- 7. BOOKING DETAILS
INSERT INTO booking_details (detail_id, booking_id, ticket_id, quantity, unit_price, subtotal) VALUES
(1, 1, 1, 1, 799.00, 799.00),
(2, 1, 2, 1, 1499.00, 1499.00),
(3, 2, 5, 1, 1299.00, 1299.00),
(4, 3, 3, 1, 2999.00, 2999.00);

SELECT setval('booking_details_detail_id_seq', 4, true);

-- 8. PAYMENTS
INSERT INTO payments (payment_id, booking_id, payment_method, amount, payment_status, transaction_id, payment_date) VALUES
(1, 1, 'UPI', 2298.00, 'SUCCESS', 'TXN-UPI-98421094', '2026-09-10 14:21:05'),
(2, 2, 'CARD', 1299.00, 'SUCCESS', 'TXN-CRD-77341209', '2026-09-11 16:46:12'),
(3, 3, 'NETBANKING', 2999.00, 'SUCCESS', 'TXN-NBK-55129034', '2026-09-12 11:11:40');

SELECT setval('payments_payment_id_seq', 3, true);

-- 9. REVIEWS
INSERT INTO reviews (review_id, user_id, event_id, rating, comment, created_at) VALUES
(1, 3, 1, 5, 'Brilliant lineup of speakers! Can not wait for the hands-on AI model deployment workshop.', '2026-09-13 18:30:00'),
(2, 4, 2, 5, 'Went to their previous tour and it was extraordinary! Booking the front pit was super smooth.', '2026-09-14 09:15:00');

SELECT setval('reviews_review_id_seq', 2, true);
