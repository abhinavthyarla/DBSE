-- ==========================================================
-- SMART EVENT MANAGEMENT & BOOKING SYSTEM (DBSE PROJECT)
-- File: schema.sql (PostgreSQL Relational Schema - 3NF)
-- ==========================================================

-- 1. DROP EXISTING TABLES IF ANY (in reverse dependency order)
DROP TABLE IF EXISTS reviews CASCADE;
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS booking_details CASCADE;
DROP TABLE IF EXISTS bookings CASCADE;
DROP TABLE IF EXISTS ticket_types CASCADE;
DROP TABLE IF EXISTS events CASCADE;
DROP TABLE IF EXISTS venues CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 2. USERS TABLE
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL DEFAULT 'USER' 
        CONSTRAINT chk_user_role CHECK (role IN ('USER', 'ORGANIZER', 'ADMIN')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. CATEGORIES TABLE
CREATE TABLE categories (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    icon_name VARCHAR(50) DEFAULT 'calendar'
);

-- 4. VENUES TABLE
CREATE TABLE venues (
    venue_id SERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(60) NOT NULL,
    state VARCHAR(60),
    capacity INTEGER NOT NULL CONSTRAINT chk_venue_capacity CHECK (capacity > 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. EVENTS TABLE
CREATE TABLE events (
    event_id SERIAL PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    category_id INTEGER NOT NULL REFERENCES categories(category_id) ON DELETE RESTRICT,
    venue_id INTEGER NOT NULL REFERENCES venues(venue_id) ON DELETE RESTRICT,
    organizer_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    banner_url TEXT,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
        CONSTRAINT chk_event_status CHECK (status IN ('ACTIVE', 'COMPLETED', 'CANCELLED')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_event_time CHECK (end_time > start_time)
);

-- 6. TICKET TYPES TABLE
CREATE TABLE ticket_types (
    ticket_id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(event_id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    price NUMERIC(10, 2) NOT NULL CONSTRAINT chk_ticket_price CHECK (price >= 0),
    total_quantity INTEGER NOT NULL CONSTRAINT chk_ticket_total_qty CHECK (total_quantity > 0),
    available_quantity INTEGER NOT NULL CONSTRAINT chk_ticket_avail_qty CHECK (available_quantity >= 0),
    CONSTRAINT chk_avail_lte_total CHECK (available_quantity <= total_quantity),
    CONSTRAINT uq_event_ticket_name UNIQUE (event_id, name)
);

-- 7. BOOKINGS TABLE
CREATE TABLE bookings (
    booking_id SERIAL PRIMARY KEY,
    booking_ref VARCHAR(30) NOT NULL UNIQUE,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    total_amount NUMERIC(10, 2) NOT NULL CONSTRAINT chk_booking_amount CHECK (total_amount >= 0),
    booking_status VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED'
        CONSTRAINT chk_booking_status CHECK (booking_status IN ('CONFIRMED', 'CANCELLED', 'PENDING')),
    booking_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. BOOKING DETAILS TABLE (Line items for each ticket type in a booking)
CREATE TABLE booking_details (
    detail_id SERIAL PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES bookings(booking_id) ON DELETE CASCADE,
    ticket_id INTEGER NOT NULL REFERENCES ticket_types(ticket_id) ON DELETE RESTRICT,
    quantity INTEGER NOT NULL CONSTRAINT chk_detail_quantity CHECK (quantity > 0),
    unit_price NUMERIC(10, 2) NOT NULL CONSTRAINT chk_detail_unit_price CHECK (unit_price >= 0),
    subtotal NUMERIC(10, 2) NOT NULL CONSTRAINT chk_detail_subtotal CHECK (subtotal >= 0)
);

-- 9. PAYMENTS TABLE
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES bookings(booking_id) ON DELETE CASCADE,
    payment_method VARCHAR(30) NOT NULL 
        CONSTRAINT chk_payment_method CHECK (payment_method IN ('UPI', 'CARD', 'NETBANKING', 'CASH')),
    amount NUMERIC(10, 2) NOT NULL CONSTRAINT chk_payment_amount CHECK (amount >= 0),
    payment_status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS'
        CONSTRAINT chk_payment_status CHECK (payment_status IN ('SUCCESS', 'FAILED', 'REFUNDED')),
    transaction_id VARCHAR(60) NOT NULL UNIQUE,
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. REVIEWS TABLE
CREATE TABLE reviews (
    review_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    event_id INTEGER NOT NULL REFERENCES events(event_id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_user_event_review UNIQUE (user_id, event_id)
);

-- 11. INDEXES FOR PERFORMANCE OPTIMIZATION
CREATE INDEX idx_events_date ON events(event_date);
CREATE INDEX idx_events_category ON events(category_id);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_ticket_types_event ON ticket_types(event_id);
CREATE INDEX idx_reviews_event ON reviews(event_id);
