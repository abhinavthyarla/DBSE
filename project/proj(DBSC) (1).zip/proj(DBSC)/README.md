# Smart Event Management & Booking System (DBSE Project)

A complete, production-grade Database Systems Engineering (DBSE) and Full-Stack Event Booking System built with **PostgreSQL**, **Python FastAPI**, **SQLAlchemy ORM**, **Responsive Web Frontend (HTML/CSS/JS)**, and **Android Client (Native App & PWA)**.

---

## Quick Start (Run Locally in 10 Seconds)

1. **Start the FastAPI Backend & Web Server**:
   ```bash
   cd backend
   python -m uvicorn app.main:app --reload --port 8000
   ```
2. **Open the Application in Browser**:
   Open [http://localhost:8000](http://localhost:8000) or open `frontend/index.html` directly.
3. **Interactive API Documentation (Swagger)**:
   Open [http://localhost:8000/docs](http://localhost:8000/docs).

---

## ⚡ Demo Accounts (Pre-configured)

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Admin** | `admin@smartevent.com` | `password123` | Full KPI dashboard, SQL reports, Event CRUD, User Management |
| **Organizer** | `alex@eventpulse.io` | `password123` | Create events, manage venues, view bookings |
| **User (Attendee)** | `aman@gmail.com` | `password123` | Browse, book tickets, UPI/Card simulation, view & cancel bookings |

*(Note: The web app includes 1-click Quick Demo login buttons on the Sign In modal!)*

---

## Project Structure

```
proj(DBSC)/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app & static file router
│   │   ├── config.py            # App settings & secrets
│   │   ├── database.py          # SQLAlchemy engine & session factory
│   │   ├── models/              # Normalized relational models (User, Event, Booking...)
│   │   ├── schemas/             # Pydantic v2 validation models
│   │   ├── auth/                # JWT tokens, bcrypt, RBAC dependencies
│   │   ├── routes/              # REST endpoints (auth, events, bookings, admin...)
│   │   └── services/            # Transactional booking engine & SQL analytics
│   ├── seed_data.py             # CLI database seeder (SQLite/PostgreSQL)
│   ├── test_api.py              # Automated test suite
│   ├── requirements.txt
│   └── .env
│
├── database/
│   ├── schema.sql               # Pure PostgreSQL 3NF DDL schema
│   ├── seed.sql                 # Sample mock data for lab viva
│   ├── views_triggers.sql       # PostgreSQL views and PL/pgSQL triggers
│   └── queries.sql              # Joins, subqueries, group by, aggregates, transactions
│
├── frontend/
│   ├── index.html               # Responsive single page application
│   ├── css/
│   │   ├── style.css            # Modern glassmorphism & dark/light theme
│   │   └── components.css       # Modals, tickets, checkout simulator, admin grid
│   ├── js/                      # Modular JavaScript clients
│   ├── manifest.json            # PWA manifest for Android installation
│   └── sw.js                    # Service worker for offline caching
│
├── android/                     # Android Studio Native Shell
│   ├── app/                     # Java/Gradle Android App with WebView bridge
│   └── README.md                # Android Studio build guide
│
├── postman/
│   └── Smart_Event_API_Collection.json # Complete API collection
│
├── docker/
│   ├── Dockerfile               # Backend container
│   └── docker-compose.yml       # PostgreSQL 16 + FastAPI + Adminer
│
└── docs/
    └── DBSE_Project_Report.md   # Complete 14-Chapter Academic Report
```

---

## Database Features (Syllabus Requirements)

1. **3NF Relational Normalization**: Eliminated partial and transitive dependencies across 9 tables (`users`, `categories`, `venues`, `events`, `ticket_types`, `bookings`, `booking_details`, `payments`, `reviews`).
2. **Integrity Constraints**: `CHECK (price >= 0)`, `CHECK (available_quantity <= total_quantity)`, `CHECK (rating BETWEEN 1 AND 5)`, `UNIQUE(email)`, `UNIQUE(booking_ref)`.
3. **Database Views**:
   - `event_sales_view`: Aggregates ticket quantities sold and gross revenue per event.
   - `popular_events_view`: Ranks events by total orders and attendee ratings.
   - `user_booking_summary_view`: Summarizes attendee lifetime expenditure.
4. **Triggers**:
   - `trg_decrement_tickets`: Decrements available tickets automatically upon booking.
   - `trg_restore_tickets`: Restores inventory when a booking is cancelled.
5. **ACID Transactions**: Atomic lock & rollback ensuring ticket counts never oversell during concurrent booking requests.

---

## Android Mobile Application

- **Option A (Native Android Studio)**: Open the `android/` directory in Android Studio and hit **Run** to launch on an emulator or physical phone.
- **Option B (Progressive Web App)**: Open the URL on Chrome in Android and tap **Install App** to get a full-screen native Android experience.

---

## Automated Verification

Run backend unit tests:
```bash
cd backend
python test_api.py
```
