from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_api():
    print("Testing /health...")
    r = client.get("/health")
    assert r.status_code == 200, f"Health failed: {r.text}"
    print("Health OK:", r.json())

    print("Testing /api/categories...")
    r = client.get("/api/categories")
    assert r.status_code == 200, f"Categories failed: {r.text}"
    print(f"Categories OK: {len(r.json())} categories found")

    print("Testing /api/events...")
    r = client.get("/api/events")
    assert r.status_code == 200, f"Events failed: {r.text}"
    events = r.json()
    print(f"Events OK: {len(events)} events found")
    assert len(events) >= 5

    print("Testing login with admin account...")
    r = client.post("/api/auth/login", json={"email": "admin@smartevent.com", "password": "password123"})
    assert r.status_code == 200, f"Login failed: {r.text}"
    token_data = r.json()
    token = token_data["access_token"]
    print("Admin login OK! Token received.")

    print("Testing /api/admin/metrics with JWT...")
    r = client.get("/api/admin/metrics", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200, f"Admin metrics failed: {r.text}"
    print("Admin metrics OK:", r.json())

    print("Testing /api/admin/reports/sales...")
    r = client.get("/api/admin/reports/sales", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200, f"Sales report failed: {r.text}"
    print(f"Sales report OK: {len(r.json())} rows returned")

    print("Testing transactional booking creation...")
    # Login as Aman
    r = client.post("/api/auth/login", json={"email": "aman@gmail.com", "password": "password123"})
    assert r.status_code == 200
    user_token = r.json()["access_token"]
    booking_payload = {
        "items": [{"ticket_id": 1, "quantity": 2}],
        "payment_method": "UPI"
    }
    r = client.post("/api/bookings", json=booking_payload, headers={"Authorization": f"Bearer {user_token}"})
    assert r.status_code == 201, f"Booking failed: {r.text}"
    created_booking = r.json()
    print(f"Booking created OK: Ref {created_booking['booking_ref']}, Total: {created_booking['total_amount']}")

    # Test booking cancellation
    bk_id = created_booking["booking_id"]
    r = client.post(f"/api/bookings/{bk_id}/cancel", headers={"Authorization": f"Bearer {user_token}"})
    assert r.status_code == 200, f"Cancel failed: {r.text}"
    assert r.json()["booking_status"] == "CANCELLED"
    print(f"Booking {bk_id} cancelled & inventory restored OK!")

    print("\nALL API BACKEND TESTS (INCLUDING ACID BOOKING & CANCEL) PASSED PERFECTLY!")

if __name__ == "__main__":
    test_api()
