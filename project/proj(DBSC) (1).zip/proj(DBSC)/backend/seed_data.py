"""
Seed Script for Smart Event Management & Booking System
Populates Users, Categories, Venues, Events, Tickets, Bookings, Payments, and Reviews
Works on both SQLite and PostgreSQL.
"""
from datetime import date, time, datetime
from decimal import Decimal
from app.database import SessionLocal, engine, Base
from app.models import (
    User, Category, Venue, Event, TicketType, Booking, BookingDetail, Payment, Review
)
from app.auth.jwt import hash_password

def seed():
    print("Creating tables if not exists...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(User).first():
            print("Database already contains data. Skipping seeding.")
            return

        print("Seeding initial data...")
        default_pwd = hash_password("password123")

        # 1. Users
        admin_user = User(user_id=1, full_name="System Administrator", email="admin@smartevent.com", password_hash=default_pwd, phone="9876543210", role="ADMIN")
        organizer_user = User(user_id=2, full_name="Alex Organizer", email="alex@eventpulse.io", password_hash=default_pwd, phone="9876543211", role="ORGANIZER")
        user_aman = User(user_id=3, full_name="Aman Sharma", email="aman@gmail.com", password_hash=default_pwd, phone="9876543212", role="USER")
        user_abhinav = User(user_id=4, full_name="Abhinav Patel", email="abhinav@gmail.com", password_hash=default_pwd, phone="9876543213", role="USER")
        user_ashish = User(user_id=5, full_name="Ashish Kumar", email="ashish@gmail.com", password_hash=default_pwd, phone="9876543214", role="USER")

        db.add_all([admin_user, organizer_user, user_aman, user_abhinav, user_ashish])
        db.commit()

        # 2. Categories
        cat_tech = Category(category_id=1, name="Technology", description="Conferences, Hackathons, AI Summits, Developer meetups", icon_name="cpu")
        cat_music = Category(category_id=2, name="Music & Concerts", description="Live concerts, acoustic nights, EDM festivals, indie jams", icon_name="music")
        cat_startup = Category(category_id=3, name="Business & Startups", description="Pitch competitions, investor summits, entrepreneurship workshops", icon_name="briefcase")
        cat_sports = Category(category_id=4, name="Sports & Fitness", description="Marathons, football championships, yoga retreats, esports tournaments", icon_name="activity")
        cat_arts = Category(category_id=5, name="Arts & Culture", description="Art exhibitions, theater plays, standup comedy, literature festivals", icon_name="palette")

        db.add_all([cat_tech, cat_music, cat_startup, cat_sports, cat_arts])
        db.commit()

        # 3. Venues
        v1 = Venue(venue_id=1, name="Grand Tech Convention Center", address="120 Ring Road, Electronic City", city="Bengaluru", state="Karnataka", capacity=2500)
        v2 = Venue(venue_id=2, name="Royal Symphony Amphitheater", address="45 Marine Lines, Nariman Point", city="Mumbai", state="Maharashtra", capacity=3500)
        v3 = Venue(venue_id=3, name="National Innovation Arena", address="Barakhamba Road, Connaught Place", city="New Delhi", state="Delhi", capacity=1800)
        v4 = Venue(venue_id=4, name="Cyber Hub Auditorium", address="DLF Phase 2, Sector 24", city="Gurugram", state="Haryana", capacity=950)
        v5 = Venue(venue_id=5, name="Marina Bay Open Grounds", address="Kamarajar Promenade, Triplicane", city="Chennai", state="Tamil Nadu", capacity=5000)

        db.add_all([v1, v2, v3, v4, v5])
        db.commit()

        # 4. Events
        e1 = Event(
            event_id=1,
            title="NextGen AI & Cloud Summit 2026",
            description="A premier global conference bringing together leading AI researchers, cloud architects, and tech innovators for keynote sessions and hands-on workshops.",
            category_id=1,
            venue_id=1,
            organizer_id=2,
            banner_url="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200",
            event_date=date(2026, 10, 15),
            start_time=time(9, 30),
            end_time=time(17, 30),
            status="ACTIVE"
        )
        e2 = Event(
            event_id=2,
            title="Electric Moonlight Music Festival",
            description="Experience an electrifying night of live indie music, psychedelic visual projections, and food trucks with top artists.",
            category_id=2,
            venue_id=2,
            organizer_id=2,
            banner_url="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200",
            event_date=date(2026, 10, 24),
            start_time=time(18, 0),
            end_time=time(23, 30),
            status="ACTIVE"
        )
        e3 = Event(
            event_id=3,
            title="SeedStage Startup Workshop & Pitch",
            description="Connect with angel investors, learn product-market fit strategies, and pitch your startup for seed funding.",
            category_id=3,
            venue_id=4,
            organizer_id=2,
            banner_url="https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=1200",
            event_date=date(2026, 11, 5),
            start_time=time(10, 0),
            end_time=time(16, 0),
            status="ACTIVE"
        )
        e4 = Event(
            event_id=4,
            title="National Corporate Esports Championship",
            description="High-octane esports tournament featuring League of Legends, Valorant, and Rocket League with a prize pool of 5 Lakhs.",
            category_id=4,
            venue_id=3,
            organizer_id=2,
            banner_url="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200",
            event_date=date(2026, 11, 12),
            start_time=time(11, 0),
            end_time=time(20, 0),
            status="ACTIVE"
        )
        e5 = Event(
            event_id=5,
            title="Midnight Comedy & Improv Night",
            description="An uncensored evening of belly-laughing standup comedy, sketches, and audience improv by national award-winning comics.",
            category_id=5,
            venue_id=4,
            organizer_id=2,
            banner_url="https://images.unsplash.com/photo-1585699324551-f6c309eedeca?w=1200",
            event_date=date(2026, 11, 20),
            start_time=time(19, 30),
            end_time=time(22, 0),
            status="ACTIVE"
        )

        db.add_all([e1, e2, e3, e4, e5])
        db.commit()

        # 5. Ticket Types
        tickets = [
            TicketType(ticket_id=1, event_id=1, name="Regular Attendee", price=Decimal("799.00"), total_quantity=300, available_quantity=290),
            TicketType(ticket_id=2, event_id=1, name="Premium Workshop Access", price=Decimal("1499.00"), total_quantity=150, available_quantity=142),
            TicketType(ticket_id=3, event_id=1, name="VIP All-Access + Dinner", price=Decimal("2999.00"), total_quantity=50, available_quantity=48),
            TicketType(ticket_id=4, event_id=2, name="General Standing", price=Decimal("599.00"), total_quantity=500, available_quantity=485),
            TicketType(ticket_id=5, event_id=2, name="Fan Pit (Front Stage)", price=Decimal("1299.00"), total_quantity=200, available_quantity=192),
            TicketType(ticket_id=6, event_id=2, name="VIP Lounge & Drinks", price=Decimal("2499.00"), total_quantity=80, available_quantity=75),
            TicketType(ticket_id=7, event_id=3, name="Founder Pass", price=Decimal("499.00"), total_quantity=100, available_quantity=95),
            TicketType(ticket_id=8, event_id=3, name="Investor & VIP Pass", price=Decimal("1999.00"), total_quantity=30, available_quantity=28),
            TicketType(ticket_id=9, event_id=4, name="Spectator Pass", price=Decimal("299.00"), total_quantity=400, available_quantity=390),
            TicketType(ticket_id=10, event_id=4, name="Pro Gamer Pit Access", price=Decimal("899.00"), total_quantity=100, available_quantity=96),
            TicketType(ticket_id=11, event_id=5, name="Silver Balcony", price=Decimal("399.00"), total_quantity=150, available_quantity=145),
            TicketType(ticket_id=12, event_id=5, name="Gold Front Row", price=Decimal("799.00"), total_quantity=75, available_quantity=70),
        ]
        db.add_all(tickets)
        db.commit()

        # 6. Bookings & Line items
        b1 = Booking(booking_id=1, booking_ref="BK-2026-1001", user_id=3, total_amount=Decimal("2298.00"), booking_status="CONFIRMED", booking_date=datetime(2026, 9, 10, 14, 20))
        b2 = Booking(booking_id=2, booking_ref="BK-2026-1002", user_id=4, total_amount=Decimal("1299.00"), booking_status="CONFIRMED", booking_date=datetime(2026, 9, 11, 16, 45))
        b3 = Booking(booking_id=3, booking_ref="BK-2026-1003", user_id=5, total_amount=Decimal("2999.00"), booking_status="CONFIRMED", booking_date=datetime(2026, 9, 12, 11, 10))

        db.add_all([b1, b2, b3])
        db.commit()

        bd1 = BookingDetail(detail_id=1, booking_id=1, ticket_id=1, quantity=1, unit_price=Decimal("799.00"), subtotal=Decimal("799.00"))
        bd2 = BookingDetail(detail_id=2, booking_id=1, ticket_id=2, quantity=1, unit_price=Decimal("1499.00"), subtotal=Decimal("1499.00"))
        bd3 = BookingDetail(detail_id=3, booking_id=2, ticket_id=5, quantity=1, unit_price=Decimal("1299.00"), subtotal=Decimal("1299.00"))
        bd4 = BookingDetail(detail_id=4, booking_id=3, ticket_id=3, quantity=1, unit_price=Decimal("2999.00"), subtotal=Decimal("2999.00"))

        db.add_all([bd1, bd2, bd3, bd4])
        db.commit()

        # 7. Payments
        p1 = Payment(payment_id=1, booking_id=1, payment_method="UPI", amount=Decimal("2298.00"), payment_status="SUCCESS", transaction_id="TXN-UPI-98421094")
        p2 = Payment(payment_id=2, booking_id=2, payment_method="CARD", amount=Decimal("1299.00"), payment_status="SUCCESS", transaction_id="TXN-CRD-77341209")
        p3 = Payment(payment_id=3, booking_id=3, payment_method="NETBANKING", amount=Decimal("2999.00"), payment_status="SUCCESS", transaction_id="TXN-NBK-55129034")

        db.add_all([p1, p2, p3])
        db.commit()

        # 8. Reviews
        r1 = Review(review_id=1, user_id=3, event_id=1, rating=5, comment="Brilliant lineup of speakers! Can not wait for the hands-on AI model deployment workshop.")
        r2 = Review(review_id=2, user_id=4, event_id=2, rating=5, comment="Went to their previous tour and it was extraordinary! Booking the front pit was super smooth.")

        db.add_all([r1, r2])
        db.commit()

        print("Database seeded successfully with Users, Events, Venues, Tickets, Bookings, Payments, and Reviews!")
    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    seed()
