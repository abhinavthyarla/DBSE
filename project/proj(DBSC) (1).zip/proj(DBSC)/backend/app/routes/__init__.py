from app.routes.auth import router as auth_router
from app.routes.events import router as events_router
from app.routes.venues import router as venues_router
from app.routes.categories import router as categories_router
from app.routes.bookings import router as bookings_router
from app.routes.payments import router as payments_router
from app.routes.reviews import router as reviews_router
from app.routes.admin import router as admin_router

__all__ = [
    "auth_router",
    "events_router",
    "venues_router",
    "categories_router",
    "bookings_router",
    "payments_router",
    "reviews_router",
    "admin_router",
]
