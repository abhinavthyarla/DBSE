import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.payment import Payment
from app.models.booking import Booking
from app.schemas.payment import PaymentSimulationRequest, PaymentResponse
from app.auth.dependencies import get_current_user
from app.models.user import User

router = APIRouter(prefix="/payments", tags=["Payments"])

@router.post("/simulate", response_model=PaymentResponse)
def simulate_payment(
    req: PaymentSimulationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    booking = db.query(Booking).filter(Booking.booking_id == req.booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")

    if booking.user_id != current_user.user_id and current_user.role != "ADMIN":
        raise HTTPException(status_code=403, detail="Not authorized to pay for this booking")

    status_str = "FAILED" if req.simulate_failure else "SUCCESS"
    txn_id = f"TXN-{req.payment_method}-{uuid.uuid4().hex[:10].upper()}"

    # Check if a payment record already exists for this booking
    existing_payment = db.query(Payment).filter(Payment.booking_id == req.booking_id).first()
    if existing_payment:
        existing_payment.payment_method = req.payment_method
        existing_payment.payment_status = status_str
        existing_payment.transaction_id = txn_id
        payment_record = existing_payment
    else:
        payment_record = Payment(
            booking_id=req.booking_id,
            payment_method=req.payment_method,
            amount=booking.total_amount,
            payment_status=status_str,
            transaction_id=txn_id
        )
        db.add(payment_record)

    if status_str == "FAILED":
        booking.booking_status = "PENDING"
    else:
        booking.booking_status = "CONFIRMED"

    db.commit()
    db.refresh(payment_record)
    return payment_record

@router.get("/booking/{booking_id}", response_model=PaymentResponse)
def get_payment_for_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    payment = db.query(Payment).filter(Payment.booking_id == booking_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="No payment found for this booking")
    return payment
