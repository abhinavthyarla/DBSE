from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import date
from app.database import get_db
from app.models.event import Event
from app.models.ticket import TicketType
from app.models.review import Review
from app.schemas.event import EventCreate, EventUpdate, EventResponse
from app.schemas.ticket import TicketTypeBase, TicketTypeCreate, TicketTypeResponse, TicketTypeUpdate
from app.auth.dependencies import require_role, get_current_user
from app.models.user import User

router = APIRouter(prefix="/events", tags=["Events"])

@router.get("", response_model=List[EventResponse])
def get_events(
    search: Optional[str] = None,
    category_id: Optional[int] = None,
    city: Optional[str] = None,
    from_date: Optional[date] = None,
    status: Optional[str] = "ACTIVE",
    db: Session = Depends(get_db)
):
    query = db.query(Event)
    if status and status != "ALL":
        query = query.filter(Event.status == status)
    if category_id:
        query = query.filter(Event.category_id == category_id)
    if search:
        query = query.filter(Event.title.ilike(f"%{search}%") | Event.description.ilike(f"%{search}%"))
    if city:
        query = query.join(Event.venue).filter(Event.venue.has(city=city))
    if from_date:
        query = query.filter(Event.event_date >= from_date)
    
    return query.order_by(Event.event_date.asc()).all()

@router.get("/{event_id}", response_model=EventResponse)
def get_event_by_id(event_id: int, db: Session = Depends(get_db)):
    event = db.query(Event).filter(Event.event_id == event_id).first()
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    return event

@router.post("", response_model=EventResponse, status_code=status.HTTP_201_CREATED)
def create_event(
    event_in: EventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("ORGANIZER", "ADMIN"))
):
    new_event = Event(
        **event_in.model_dump(),
        organizer_id=current_user.user_id
    )
    db.add(new_event)
    db.commit()
    db.refresh(new_event)

    # Automatically add default Standard and VIP ticket types for convenience
    tier_regular = TicketType(
        event_id=new_event.event_id,
        name="General Admission",
        price=499.00,
        total_quantity=200,
        available_quantity=200
    )
    tier_vip = TicketType(
        event_id=new_event.event_id,
        name="VIP Pass",
        price=1499.00,
        total_quantity=50,
        available_quantity=50
    )
    db.add(tier_regular)
    db.add(tier_vip)
    db.commit()
    db.refresh(new_event)

    return new_event

@router.put("/{event_id}", response_model=EventResponse)
def update_event(
    event_id: int,
    event_in: EventUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("ORGANIZER", "ADMIN"))
):
    event = db.query(Event).filter(Event.event_id == event_id).first()
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    
    if current_user.role != "ADMIN" and event.organizer_id != current_user.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to edit this event")
    
    update_data = event_in.model_dump(exclude_unset=True)
    for field, val in update_data.items():
        setattr(event, field, val)
    
    db.commit()
    db.refresh(event)
    return event

@router.delete("/{event_id}", status_code=status.HTTP_200_OK)
def delete_event(
    event_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("ORGANIZER", "ADMIN"))
):
    event = db.query(Event).filter(Event.event_id == event_id).first()
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    
    if current_user.role != "ADMIN" and event.organizer_id != current_user.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to delete this event")
    
    db.delete(event)
    db.commit()
    return {"message": f"Event '{event.title}' successfully deleted"}

# Ticket Tier sub-routes
@router.post("/{event_id}/tickets", response_model=TicketTypeResponse, status_code=status.HTTP_201_CREATED)
def add_ticket_type(
    event_id: int,
    ticket_in: TicketTypeBase,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("ORGANIZER", "ADMIN"))
):
    event = db.query(Event).filter(Event.event_id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    ticket = TicketType(
        event_id=event_id,
        name=ticket_in.name,
        price=ticket_in.price,
        total_quantity=ticket_in.total_quantity,
        available_quantity=ticket_in.total_quantity
    )
    db.add(ticket)
    db.commit()
    db.refresh(ticket)
    return ticket

@router.put("/tickets/{ticket_id}", response_model=TicketTypeResponse)
def update_ticket_type(
    ticket_id: int,
    ticket_in: TicketTypeUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("ORGANIZER", "ADMIN"))
):
    ticket = db.query(TicketType).filter(TicketType.ticket_id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket type not found")
    
    update_data = ticket_in.model_dump(exclude_unset=True)
    for k, v in update_data.items():
        setattr(ticket, k, v)
    
    db.commit()
    db.refresh(ticket)
    return ticket
