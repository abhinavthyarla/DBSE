from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.user import User
from app.schemas.user import UserResponse
from app.auth.dependencies import require_role
from app.services.report_service import get_dashboard_metrics, get_event_sales_report, get_popular_events_report

router = APIRouter(prefix="/admin", tags=["Admin & Reports"])

@router.get("/metrics")
def read_metrics(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN"))
):
    return get_dashboard_metrics(db)

@router.get("/reports/sales")
def read_sales_report(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN", "ORGANIZER"))
):
    return get_event_sales_report(db)

@router.get("/reports/popular")
def read_popular_events_report(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN", "ORGANIZER"))
):
    return get_popular_events_report(db)

@router.get("/users", response_model=List[UserResponse])
def get_all_users(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN"))
):
    return db.query(User).order_by(User.created_at.desc()).all()

@router.put("/users/{user_id}/role")
def update_user_role(
    user_id: int,
    role: str,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN"))
):
    if role not in ("USER", "ORGANIZER", "ADMIN"):
        raise HTTPException(status_code=400, detail="Invalid role specified")
    
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.role = role
    db.commit()
    return {"message": f"User role successfully updated to {role}"}

@router.delete("/users/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN"))
):
    if user_id == admin.user_id:
        raise HTTPException(status_code=400, detail="Cannot delete your own admin account")
    
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db.delete(user)
    db.commit()
    return {"message": f"User {user.full_name} deleted successfully"}
