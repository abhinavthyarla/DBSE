from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.booking import Booking
from app.schemas.booking import BookingCreateRequest, BookingResponse
from app.auth.dependencies import get_current_user, require_role
from app.models.user import User
from app.services.booking_service import create_booking_transaction, cancel_booking_transaction

router = APIRouter(prefix="/bookings", tags=["Bookings"])

@router.post("", response_model=BookingResponse, status_code=status.HTTP_201_CREATED)
def create_booking(
    booking_in: BookingCreateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return create_booking_transaction(db, user_id=current_user.user_id, booking_in=booking_in)

@router.get("/my", response_model=List[BookingResponse])
def get_my_bookings(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return db.query(Booking)\
             .filter(Booking.user_id == current_user.user_id)\
             .order_by(Booking.booking_date.desc())\
             .all()

@router.get("/{booking_id}", response_model=BookingResponse)
def get_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    booking = db.query(Booking).filter(Booking.booking_id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    if current_user.role not in ("ADMIN", "ORGANIZER") and booking.user_id != current_user.user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return booking

@router.post("/{booking_id}/cancel", response_model=BookingResponse)
def cancel_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    is_admin = current_user.role == "ADMIN"
    return cancel_booking_transaction(db, booking_id=booking_id, user_id=current_user.user_id, is_admin=is_admin)

@router.get("", response_model=List[BookingResponse])
def get_all_bookings(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role("ADMIN", "ORGANIZER"))
):
    return db.query(Booking).order_by(Booking.booking_date.desc()).all()
