from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.venue import Venue
from app.schemas.event import VenueResponse, VenueCreate
from app.auth.dependencies import require_role

router = APIRouter(prefix="/venues", tags=["Venues"])

@router.get("", response_model=List[VenueResponse])
def get_venues(db: Session = Depends(get_db)):
    return db.query(Venue).all()

@router.post("", response_model=VenueResponse, status_code=status.HTTP_201_CREATED)
def create_venue(
    venue_in: VenueCreate,
    db: Session = Depends(get_db),
    admin=Depends(require_role("ADMIN", "ORGANIZER"))
):
    venue = Venue(**venue_in.model_dump())
    db.add(venue)
    db.commit()
    db.refresh(venue)
    return venue
