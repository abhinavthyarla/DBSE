from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.review import Review
from app.models.event import Event
from app.schemas.review import ReviewCreate, ReviewResponse
from app.auth.dependencies import get_current_user
from app.models.user import User

router = APIRouter(prefix="/reviews", tags=["Reviews"])

@router.get("/event/{event_id}", response_model=List[ReviewResponse])
def get_event_reviews(event_id: int, db: Session = Depends(get_db)):
    return db.query(Review).filter(Review.event_id == event_id).order_by(Review.created_at.desc()).all()

@router.post("", response_model=ReviewResponse, status_code=status.HTTP_201_CREATED)
def submit_review(
    review_in: ReviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    event = db.query(Event).filter(Event.event_id == review_in.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    existing = db.query(Review).filter(
        Review.user_id == current_user.user_id,
        Review.event_id == review_in.event_id
    ).first()
    
    if existing:
        # Update existing review
        existing.rating = review_in.rating
        existing.comment = review_in.comment
        db.commit()
        db.refresh(existing)
        return existing
    
    new_review = Review(
        user_id=current_user.user_id,
        event_id=review_in.event_id,
        rating=review_in.rating,
        comment=review_in.comment
    )
    db.add(new_review)
    db.commit()
    db.refresh(new_review)
    return new_review
