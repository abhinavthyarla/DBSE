from sqlalchemy import Column, Integer, String, Numeric, DateTime, ForeignKey, func, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class Booking(Base):
    __tablename__ = "bookings"

    booking_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    booking_ref = Column(String(30), unique=True, nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False, index=True)
    total_amount = Column(Numeric(10, 2), nullable=False)
    booking_status = Column(String(20), nullable=False, default="CONFIRMED")
    booking_date = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        CheckConstraint("total_amount >= 0", name="chk_booking_amount"),
        CheckConstraint("booking_status IN ('CONFIRMED', 'CANCELLED', 'PENDING')", name="chk_booking_status"),
    )

    user = relationship("User", back_populates="bookings")
    details = relationship("BookingDetail", back_populates="booking", cascade="all, delete-orphan")
    payments = relationship("Payment", back_populates="booking", cascade="all, delete-orphan")


class BookingDetail(Base):
    __tablename__ = "booking_details"

    detail_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    booking_id = Column(Integer, ForeignKey("bookings.booking_id", ondelete="CASCADE"), nullable=False, index=True)
    ticket_id = Column(Integer, ForeignKey("ticket_types.ticket_id", ondelete="RESTRICT"), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Numeric(10, 2), nullable=False)
    subtotal = Column(Numeric(10, 2), nullable=False)

    __table_args__ = (
        CheckConstraint("quantity > 0", name="chk_detail_quantity"),
        CheckConstraint("unit_price >= 0", name="chk_detail_unit_price"),
        CheckConstraint("subtotal >= 0", name="chk_detail_subtotal"),
    )

    booking = relationship("Booking", back_populates="details")
    ticket_type = relationship("TicketType", back_populates="booking_details")
