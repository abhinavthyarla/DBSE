from sqlalchemy import Column, Integer, String, Text, Date, Time, DateTime, ForeignKey, func, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class Event(Base):
    __tablename__ = "events"

    event_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    title = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    category_id = Column(Integer, ForeignKey("categories.category_id", ondelete="RESTRICT"), nullable=False, index=True)
    venue_id = Column(Integer, ForeignKey("venues.venue_id", ondelete="RESTRICT"), nullable=False)
    organizer_id = Column(Integer, ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False)
    banner_url = Column(Text, nullable=True)
    event_date = Column(Date, nullable=False, index=True)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    status = Column(String(20), nullable=False, default="ACTIVE")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        CheckConstraint("status IN ('ACTIVE', 'COMPLETED', 'CANCELLED')", name="chk_event_status"),
    )

    category = relationship("Category", back_populates="events")
    venue = relationship("Venue", back_populates="events")
    organizer = relationship("User", back_populates="events_organized")
    ticket_types = relationship("TicketType", back_populates="event", cascade="all, delete-orphan")
    reviews = relationship("Review", back_populates="event", cascade="all, delete-orphan")
