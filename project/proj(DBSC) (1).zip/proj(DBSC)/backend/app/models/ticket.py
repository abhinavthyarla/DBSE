from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class TicketType(Base):
    __tablename__ = "ticket_types"

    ticket_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("events.event_id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(50), nullable=False)
    price = Column(Numeric(10, 2), nullable=False)
    total_quantity = Column(Integer, nullable=False)
    available_quantity = Column(Integer, nullable=False)

    __table_args__ = (
        CheckConstraint("price >= 0", name="chk_ticket_price"),
        CheckConstraint("total_quantity > 0", name="chk_ticket_total_qty"),
        CheckConstraint("available_quantity >= 0", name="chk_ticket_avail_qty"),
        CheckConstraint("available_quantity <= total_quantity", name="chk_avail_lte_total"),
        UniqueConstraint("event_id", "name", name="uq_event_ticket_name"),
    )

    event = relationship("Event", back_populates="ticket_types")
    booking_details = relationship("BookingDetail", back_populates="ticket_type")
