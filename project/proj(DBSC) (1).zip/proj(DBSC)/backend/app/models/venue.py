from sqlalchemy import Column, Integer, String, Text, DateTime, func, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class Venue(Base):
    __tablename__ = "venues"

    venue_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(120), nullable=False)
    address = Column(Text, nullable=False)
    city = Column(String(60), nullable=False, index=True)
    state = Column(String(60), nullable=True)
    capacity = Column(Integer, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        CheckConstraint("capacity > 0", name="chk_venue_capacity"),
    )

    events = relationship("Event", back_populates="venue")
