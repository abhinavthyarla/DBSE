from sqlalchemy import Column, Integer, String, Numeric, DateTime, ForeignKey, func, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class Payment(Base):
    __tablename__ = "payments"

    payment_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    booking_id = Column(Integer, ForeignKey("bookings.booking_id", ondelete="CASCADE"), nullable=False, index=True)
    payment_method = Column(String(30), nullable=False)
    amount = Column(Numeric(10, 2), nullable=False)
    payment_status = Column(String(20), nullable=False, default="SUCCESS")
    transaction_id = Column(String(60), unique=True, nullable=False, index=True)
    payment_date = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        CheckConstraint("payment_method IN ('UPI', 'CARD', 'NETBANKING', 'CASH')", name="chk_payment_method"),
        CheckConstraint("amount >= 0", name="chk_payment_amount"),
        CheckConstraint("payment_status IN ('SUCCESS', 'FAILED', 'REFUNDED')", name="chk_payment_status"),
    )

    booking = relationship("Booking", back_populates="payments")
