from sqlalchemy import Column, Integer, Text, DateTime, ForeignKey, func, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class Review(Base):
    __tablename__ = "reviews"

    review_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.user_id", ondelete="CASCADE"), nullable=False, index=True)
    event_id = Column(Integer, ForeignKey("events.event_id", ondelete="CASCADE"), nullable=False, index=True)
    rating = Column(Integer, nullable=False)
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        CheckConstraint("rating BETWEEN 1 AND 5", name="chk_review_rating"),
        UniqueConstraint("user_id", "event_id", name="uq_user_event_review"),
    )

    user = relationship("User", back_populates="reviews")
    event = relationship("Event", back_populates="reviews")
