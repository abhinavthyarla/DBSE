from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from app.models.event import Event
from app.models.user import User
from app.models.booking import Booking, BookingDetail
from app.models.ticket import TicketType
from app.models.venue import Venue
from app.models.category import Category
from app.models.review import Review

def get_dashboard_metrics(db: Session) -> dict:
    total_users = db.query(func.count(User.user_id)).scalar() or 0
    total_events = db.query(func.count(Event.event_id)).scalar() or 0
    total_bookings = db.query(func.count(Booking.booking_id)).filter(Booking.booking_status == "CONFIRMED").scalar() or 0
    
    total_revenue = db.query(func.sum(Booking.total_amount)).filter(Booking.booking_status == "CONFIRMED").scalar() or Decimal("0.00")
    
    total_tickets_sold = db.query(func.sum(BookingDetail.quantity))\
        .join(Booking, BookingDetail.booking_id == Booking.booking_id)\
        .filter(Booking.booking_status == "CONFIRMED").scalar() or 0

    return {
        "total_users": total_users,
        "total_events": total_events,
        "total_bookings": total_bookings,
        "total_revenue": float(total_revenue),
        "total_tickets_sold": int(total_tickets_sold)
    }

def get_event_sales_report(db: Session) -> list:
    results = db.query(
        Event.event_id,
        Event.title,
        Category.name.label("category_name"),
        Venue.name.label("venue_name"),
        Event.event_date,
        func.coalesce(func.sum(BookingDetail.quantity), 0).label("tickets_sold"),
        func.coalesce(func.sum(BookingDetail.subtotal), Decimal("0.00")).label("gross_revenue")
    ).join(Category, Event.category_id == Category.category_id)\
     .join(Venue, Event.venue_id == Venue.venue_id)\
     .outerjoin(TicketType, Event.event_id == TicketType.event_id)\
     .outerjoin(BookingDetail, TicketType.ticket_id == BookingDetail.ticket_id)\
     .outerjoin(Booking, (BookingDetail.booking_id == Booking.booking_id) & (Booking.booking_status == "CONFIRMED"))\
     .group_by(Event.event_id, Event.title, Category.name, Venue.name, Event.event_date)\
     .order_by(desc("gross_revenue"))\
     .all()

    report = []
    for row in results:
        report.append({
            "event_id": row.event_id,
            "title": row.title,
            "category": row.category_name,
            "venue": row.venue_name,
            "event_date": str(row.event_date),
            "tickets_sold": int(row.tickets_sold),
            "revenue": float(row.gross_revenue)
        })
    return report

def get_popular_events_report(db: Session) -> list:
    results = db.query(
        Event.event_id,
        Event.title,
        Category.name.label("category"),
        func.count(func.distinct(Booking.booking_id)).label("total_orders"),
        func.coalesce(func.avg(Review.rating), 0.0).label("avg_rating"),
        func.count(Review.review_id).label("reviews_count")
    ).join(Category, Event.category_id == Category.category_id)\
     .outerjoin(TicketType, Event.event_id == TicketType.event_id)\
     .outerjoin(BookingDetail, TicketType.ticket_id == BookingDetail.ticket_id)\
     .outerjoin(Booking, (BookingDetail.booking_id == Booking.booking_id) & (Booking.booking_status == "CONFIRMED"))\
     .outerjoin(Review, Event.event_id == Review.event_id)\
     .group_by(Event.event_id, Event.title, Category.name)\
     .order_by(desc("total_orders"))\
     .all()

    report = []
    for row in results:
        report.append({
            "event_id": row.event_id,
            "title": row.title,
            "category": row.category,
            "total_orders": int(row.total_orders),
            "avg_rating": round(float(row.avg_rating), 1),
            "reviews_count": int(row.reviews_count)
        })
    return report
