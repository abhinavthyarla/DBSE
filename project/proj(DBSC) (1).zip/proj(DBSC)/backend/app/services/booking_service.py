import uuid
from decimal import Decimal
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app.models.booking import Booking, BookingDetail
from app.models.ticket import TicketType
from app.models.payment import Payment
from app.schemas.booking import BookingCreateRequest

def create_booking_transaction(db: Session, user_id: int, booking_in: BookingCreateRequest) -> Booking:
    """
    Transactional Booking Service:
    Ensures ACID compliance:
    1. Verifies requested ticket types and availability
    2. Decrements ticket quantities atomically
    3. Creates Booking and BookingDetail records
    4. Records initial Payment
    If any check fails, rolls back the entire transaction.
    """
    total_amount = Decimal("0.00")
    details_to_create = []

    try:
        for item in booking_in.items:
            # Fetch ticket type with lock
            ticket = db.query(TicketType).filter(TicketType.ticket_id == item.ticket_id).with_for_update().first()
            if not ticket:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Ticket type with ID {item.ticket_id} not found"
                )

            if ticket.available_quantity < item.quantity:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Only {ticket.available_quantity} tickets available for '{ticket.name}'. Requested: {item.quantity}"
                )

            subtotal = ticket.price * Decimal(item.quantity)
            total_amount += subtotal

            # Decrement available tickets
            ticket.available_quantity -= item.quantity

            details_to_create.append({
                "ticket_id": ticket.ticket_id,
                "quantity": item.quantity,
                "unit_price": ticket.price,
                "subtotal": subtotal
            })

        # Generate unique booking reference
        short_id = uuid.uuid4().hex[:6].upper()
        booking_ref = f"BK-2026-{short_id}"

        # Create Booking
        new_booking = Booking(
            booking_ref=booking_ref,
            user_id=user_id,
            total_amount=total_amount,
            booking_status="CONFIRMED"
        )
        db.add(new_booking)
        db.flush() # populate new_booking.booking_id

        # Create Booking Details
        for d in details_to_create:
            detail_record = BookingDetail(
                booking_id=new_booking.booking_id,
                ticket_id=d["ticket_id"],
                quantity=d["quantity"],
                unit_price=d["unit_price"],
                subtotal=d["subtotal"]
            )
            db.add(detail_record)

        # Create initial simulated Payment record
        txn_id = f"TXN-{booking_in.payment_method}-{uuid.uuid4().hex[:8].upper()}"
        payment_record = Payment(
            booking_id=new_booking.booking_id,
            payment_method=booking_in.payment_method,
            amount=total_amount,
            payment_status="SUCCESS",
            transaction_id=txn_id
        )
        db.add(payment_record)

        db.commit()
        db.refresh(new_booking)
        return new_booking

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process booking transaction: {str(e)}"
        )


def cancel_booking_transaction(db: Session, booking_id: int, user_id: int, is_admin: bool = False) -> Booking:
    """
    Cancels a booking and restores the ticket quantities back into the available pool.
    """
    try:
        booking = db.query(Booking).filter(Booking.booking_id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        if not is_admin and booking.user_id != user_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Cannot cancel another user's booking")

        if booking.booking_status == "CANCELLED":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Booking is already cancelled")

        # Restore tickets
        for detail in booking.details:
            ticket = db.query(TicketType).filter(TicketType.ticket_id == detail.ticket_id).with_for_update().first()
            if ticket:
                ticket.available_quantity += detail.quantity

        booking.booking_status = "CANCELLED"
        
        # Update payment status if exists
        for payment in booking.payments:
            payment.payment_status = "REFUNDED"

        db.commit()
        db.refresh(booking)
        return booking

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to cancel booking: {str(e)}"
        )
