from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from decimal import Decimal

class PaymentSimulationRequest(BaseModel):
    booking_id: int
    payment_method: str = Field("UPI", pattern="^(UPI|CARD|NETBANKING|CASH)$")
    upi_id: Optional[str] = None
    card_number: Optional[str] = None
    simulate_failure: Optional[bool] = False

class PaymentResponse(BaseModel):
    payment_id: int
    booking_id: int
    payment_method: str
    amount: Decimal
    payment_status: str
    transaction_id: str
    payment_date: Optional[datetime] = None

    class Config:
        from_attributes = True
