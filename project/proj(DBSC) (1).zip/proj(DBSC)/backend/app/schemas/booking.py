from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from app.schemas.ticket import TicketTypeResponse

class BookingItemRequest(BaseModel):
    ticket_id: int
    quantity: int = Field(..., gt=0)

class BookingCreateRequest(BaseModel):
    items: List[BookingItemRequest] = Field(..., min_length=1)
    payment_method: str = Field("UPI", pattern="^(UPI|CARD|NETBANKING|CASH)$")

class BookingDetailResponse(BaseModel):
    detail_id: int
    ticket_id: int
    quantity: int
    unit_price: Decimal
    subtotal: Decimal
    ticket_type: Optional[TicketTypeResponse] = None

    class Config:
        from_attributes = True

class BookingResponse(BaseModel):
    booking_id: int
    booking_ref: str
    user_id: int
    total_amount: Decimal
    booking_status: str
    booking_date: Optional[datetime] = None
    details: List[BookingDetailResponse] = []

    class Config:
        from_attributes = True
