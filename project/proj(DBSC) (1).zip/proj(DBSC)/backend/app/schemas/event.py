from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date, time, datetime
from app.schemas.ticket import TicketTypeResponse

class CategoryResponse(BaseModel):
    category_id: int
    name: str
    description: Optional[str] = None
    icon_name: Optional[str] = None

    class Config:
        from_attributes = True

class CategoryCreate(BaseModel):
    name: str
    description: Optional[str] = None
    icon_name: Optional[str] = "calendar"


class VenueBase(BaseModel):
    name: str = Field(..., max_length=120)
    address: str
    city: str
    state: Optional[str] = None
    capacity: int = Field(..., gt=0)

class VenueCreate(VenueBase):
    pass

class VenueResponse(VenueBase):
    venue_id: int
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class EventBase(BaseModel):
    title: str = Field(..., max_length=150)
    description: Optional[str] = None
    category_id: int
    venue_id: int
    banner_url: Optional[str] = None
    event_date: date
    start_time: time
    end_time: time
    status: Optional[str] = "ACTIVE"

class EventCreate(EventBase):
    pass

class EventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category_id: Optional[int] = None
    venue_id: Optional[int] = None
    banner_url: Optional[str] = None
    event_date: Optional[date] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    status: Optional[str] = None

class EventResponse(EventBase):
    event_id: int
    organizer_id: int
    created_at: Optional[datetime] = None
    category: Optional[CategoryResponse] = None
    venue: Optional[VenueResponse] = None
    ticket_types: Optional[List[TicketTypeResponse]] = []

    class Config:
        from_attributes = True
