from pydantic import BaseModel, Field
from typing import Optional
from decimal import Decimal

class TicketTypeBase(BaseModel):
    name: str = Field(..., max_length=50)
    price: Decimal = Field(..., ge=0)
    total_quantity: int = Field(..., gt=0)

class TicketTypeCreate(TicketTypeBase):
    event_id: int

class TicketTypeUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[Decimal] = None
    total_quantity: Optional[int] = None
    available_quantity: Optional[int] = None

class TicketTypeResponse(TicketTypeBase):
    ticket_id: int
    event_id: int
    available_quantity: int

    class Config:
        from_attributes = True
