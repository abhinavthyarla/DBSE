import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    PROJECT_NAME: str = "Smart Event Management & Booking System"
    VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api"
    
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./smart_event.db")
    
    SECRET_KEY: str = os.getenv("SECRET_KEY", "smart_event_dbse_super_secret_jwt_key_2026_x89f")
    ALGORITHM: str = os.getenv("ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))
    
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")

settings = Settings()
