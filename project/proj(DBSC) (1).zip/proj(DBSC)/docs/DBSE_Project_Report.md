# Smart Event Management & Booking System
## Database Systems Engineering (DBSE) Project Report

---

### DECLARATION
I hereby declare that this project report entitled **"Smart Event Management & Booking System"** submitted in partial fulfillment of the requirements for the degree in Computer Science & Engineering is a bona fide record of independent work done by me under academic supervision.

---

### CERTIFICATE
This is to certify that the project entitled **"Smart Event Management & Booking System"** submitted by the student is evaluated and found satisfactory for the course **Database Systems Engineering (DBSE)**.

---

### ACKNOWLEDGEMENT
I express my sincere gratitude to my faculty guides and peers for their continuous guidance, architectural recommendations, and encouragement throughout the research and implementation of this relational database engineering project.

---

### ABSTRACT
Modern event management platforms suffer from data concurrency bottlenecks, overbooking anomalies, and data redundancy when event, ticket, and booking entities are improperly decoupled. This project presents the design and realization of a robust, fully normalized (3NF) relational database system powered by PostgreSQL and SQLAlchemy, encapsulated by a high-throughput Python FastAPI backend and an interactive web and Android mobile client. The database incorporates explicit integrity constraints, multi-tier relationship cardinalities, PL/pgSQL triggers for automatic inventory synchronization, analytical database views, and atomic ACID transactions to eliminate overbooking during concurrent ticket purchases.

---

## CHAPTER 1: INTRODUCTION
The Smart Event Management & Booking System addresses the end-to-end lifecycle of event discovery, tiered ticket reservation, simulated payment processing, attendee ticketing, and organizer reporting. Traditional event databases frequently store denormalized venue or customer attributes repeatedly within booking records, causing update, insertion, and deletion anomalies. By designing a third-normal-form (3NF) schema with foreign key cascades, unique constraints, check constraints, and transactional locks, the system guarantees database consistency and high data integrity.

---

## CHAPTER 2: SYSTEM REQUIREMENTS
### 2.1 Functional Requirements
- **User Module**: User registration, login via hashed passwords, JWT authentication, event catalog browsing, real-time ticket availability inspection, tiered ticket reservation, simulated UPI/Card payment, booking cancellation, review submission.
- **Organizer Module**: Event creation with venue selection, tiered ticket configuration (Regular, VIP), attendee tracking.
- **Admin Module**: Global KPI dashboard (gross revenue, total orders, active events, registered users), venue management, SQL reporting views inspection, and user role promotion/demotion.

### 2.2 Non-Functional Requirements
- **ACID Compliance**: Concurrency control preventing duplicate ticket issuance beyond capacity.
- **Security**: Bcrypt salted password hashing and role-based access control (RBAC).
- **Responsiveness**: Sub-100ms API response latency and mobile viewport adaptability for Android.

---

## CHAPTER 3: TECHNOLOGY STACK
- **Frontend**: HTML5, Vanilla CSS (Glassmorphic Design Tokens, Responsive Flex/Grid), Vanilla JavaScript (Fetch API, Modular Controllers), Progressive Web App (PWA) Manifest.
- **Mobile Android Client**: Android Studio Native WebView Shell with Hardware Acceleration and Cleartext Network Bridge (`android/`).
- **Backend API**: Python 3.12, FastAPI (Asynchronous ASGI Framework), Pydantic v2 (Data Validation).
- **ORM & Database Engine**: SQLAlchemy 2.0, PostgreSQL 16 (Production/Docker), SQLite (Zero-Config Local Dev Fallback).
- **Authentication**: JWT (JSON Web Tokens) with HMAC-SHA256 and Bcrypt.
- **Containerization**: Docker & Docker-Compose.

---

## CHAPTER 4: SYSTEM ARCHITECTURE
The system is constructed upon a 5-layer decoupled architecture:
1. **Presentation Layer**: Responsive Web Application + Android WebView Client.
2. **API & Routing Layer**: FastAPI routers handling CORS, Bearer tokens, and HTTP status codes.
3. **Business Logic Layer**: Concurrency checking, ticket availability verification, payment simulation.
4. **Data Access Layer (ORM)**: SQLAlchemy models, relations, session scopes.
5. **Database Layer**: PostgreSQL normalized tables, foreign keys, CHECK constraints, triggers, and views.

---

## CHAPTER 5: DATABASE DESIGN & NORMALIZATION

### 5.1 Normalization Process
- **1NF**: Atomic column values, distinct column names, unique primary keys (`user_id`, `event_id`, `booking_id`).
- **2NF**: Elimination of partial dependencies. All non-prime attributes are fully functionally dependent on the entire composite primary key in junction tables (e.g. `booking_details` depends on `detail_id`).
- **3NF**: Elimination of transitive functional dependencies. Venue details (address, capacity, city) are separated into `venues` table rather than stored in `events` or `bookings`.

### 5.2 Relational Entities & Schema Definition
- `users`: `(user_id [PK], full_name, email [UQ], password_hash, phone, role)`
- `categories`: `(category_id [PK], name [UQ], description, icon_name)`
- `venues`: `(venue_id [PK], name, address, city, state, capacity)`
- `events`: `(event_id [PK], title, category_id [FK], venue_id [FK], organizer_id [FK], event_date, start_time, end_time, status)`
- `ticket_types`: `(ticket_id [PK], event_id [FK], name, price, total_quantity, available_quantity)`
- `bookings`: `(booking_id [PK], booking_ref [UQ], user_id [FK], total_amount, booking_status, booking_date)`
- `booking_details`: `(detail_id [PK], booking_id [FK], ticket_id [FK], quantity, unit_price, subtotal)`
- `payments`: `(payment_id [PK], booking_id [FK], payment_method, amount, payment_status, transaction_id [UQ])`
- `reviews`: `(review_id [PK], user_id [FK], event_id [FK], rating, comment)`

---

## CHAPTER 6: IMPLEMENTATION DETAILS
- **Transaction Management**: The `booking_service.create_booking_transaction()` acquires row-level locks on ticket rows using `with_for_update()`, compares `available_quantity` against requested tickets, decrements inventory, inserts booking and payment records, and commits atomically. Any error triggers an immediate `db.rollback()`.
- **Triggers**: PostgreSQL trigger `trg_decrement_tickets` decrements inventory automatically upon detail insertion, and `trg_restore_tickets` replenishes stock upon status transition to `'CANCELLED'`.
- **Analytical Views**: `event_sales_view`, `popular_events_view`, and `user_booking_summary_view` encapsulate multi-table JOINs and GROUP BY aggregation logic.

---

## CHAPTER 7: FEATURES & INTERFACES
- **Live Event Catalog**: Real-time category filtering, search debounce, responsive cards.
- **Interactive Ticket Pass**: Generates unique reference code (`BK-2026-XXXX`) and verifiable QR code image.
- **Simulated Payment Gateway**: Supports UPI (QR / VPA), Credit/Debit Cards, and Net Banking, featuring a deliberate "Simulate Failure" toggle to prove transactional rollback during viva examination.
- **Admin Dashboard**: Live KPI metrics, dynamic sales charts, event management table, and raw SQL view viewers.

---

## CHAPTER 8: TESTING & VERIFICATION
- **Unit & Integration Testing**: Validated via `backend/test_api.py` covering health, categories, event filtering, admin authentication, metric retrieval, ACID booking creation, and cancellation restoration.
- **Postman API Suite**: Documented in `postman/Smart_Event_API_Collection.json`.
- **Security Testing**: 401 Unauthorized returned for missing tokens; 403 Forbidden returned when a normal user accesses `/api/admin/*` endpoints.

---

## CHAPTER 9: DEPLOYMENT
- **Local Dev Server**:
  ```bash
  cd backend
  uvicorn app.main:app --reload --port 8000
  ```
- **Docker Compose Deployment**:
  ```bash
  cd docker
  docker-compose up -d --build
  ```

---

## CHAPTER 10: CHALLENGES & LIMITATIONS
- **Concurrent Race Conditions**: Mitigated via transactional row locks and database CHECK constraints.
- **Network Latency in Mobile Clients**: Addressed via service worker caching and Android WebView cache directives.

---

## CHAPTER 11: FUTURE ENHANCEMENTS
- Integration with live payment gateways (Razorpay / Stripe Webhooks).
- Seat mapping and interactive theater chair reservation.
- Push notifications on Android via Firebase Cloud Messaging (FCM).

---

## CHAPTER 12: CONCLUSION
The Smart Event Management & Booking System effectively fulfills all Database Systems Engineering principles by harmonizing normalization, data integrity constraints, advanced SQL triggers, views, and ACID transactions with a modern Python FastAPI backend and responsive Android/web clients.

---

## CHAPTER 13: REFERENCES
1. Silberschatz, A., Korth, H. F., & Sudarshan, S. *Database System Concepts*, 7th Edition, McGraw-Hill.
2. PostgreSQL Global Development Group. *PostgreSQL 16 Documentation*.
3. FastAPI Documentation: https://fastapi.tiangolo.com/
4. SQLAlchemy ORM Documentation: https://docs.sqlalchemy.org/

---

## CHAPTER 14: APPENDICES
- Complete SQL Schema: `database/schema.sql`
- Seed Script: `database/seed.sql`
- Views & Triggers: `database/views_triggers.sql`
- Analytical Queries: `database/queries.sql`
- Postman Collection: `postman/Smart_Event_API_Collection.json`
