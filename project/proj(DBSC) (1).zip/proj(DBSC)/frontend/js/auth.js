// Authentication & State Management

let currentUser = null;

function getCurrentUser() {
  if (currentUser) return currentUser;
  const stored = localStorage.getItem(CONFIG.STORAGE_KEYS.USER);
  if (stored) {
    try {
      currentUser = JSON.parse(stored);
      return currentUser;
    } catch {
      return null;
    }
  }
  return null;
}

function setCurrentUser(user, token) {
  currentUser = user;
  if (user) {
    localStorage.setItem(CONFIG.STORAGE_KEYS.USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(CONFIG.STORAGE_KEYS.USER);
  }
  if (token) {
    localStorage.setItem(CONFIG.STORAGE_KEYS.TOKEN, token);
  } else if (!user) {
    localStorage.removeItem(CONFIG.STORAGE_KEYS.TOKEN);
  }
  updateAuthUI();
}

async function loginUser(email, password) {
  try {
    const data = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });

    setCurrentUser(data.user, data.access_token);
    showToast(`Welcome back, ${data.user.full_name}!`, 'success');
    closeAuthModal();
    
    // Refresh user's bookings or admin tabs if needed
    if (typeof loadEvents === 'function') loadEvents();
    if (typeof loadMyBookings === 'function') loadMyBookings();
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    return false;
  }
}

async function registerUser(fullName, email, password, phone, role = 'USER') {
  try {
    const data = await apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        full_name: fullName,
        email,
        password,
        phone,
        role
      })
    });

    setCurrentUser(data.user, data.access_token);
    showToast(`Account registered successfully! Welcome, ${data.user.full_name}`, 'success');
    closeAuthModal();
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    return false;
  }
}

function logoutUser() {
  setCurrentUser(null, null);
  showToast('You have been logged out.', 'info');
  switchTab('events');
}

function updateAuthUI() {
  const user = getCurrentUser();
  const authNav = document.getElementById('auth-nav-container');
  const adminNavItem = document.getElementById('nav-admin');

  if (!authNav) return;

  if (user) {
    const roleBadgeClass = user.role === 'ADMIN' ? 'badge-admin' : (user.role === 'ORGANIZER' ? 'badge-organizer' : 'badge-user');
    authNav.innerHTML = `
      <div class="user-profile-badge">
        <div class="avatar">${user.full_name.charAt(0).toUpperCase()}</div>
        <div class="user-meta">
          <span class="user-name">${user.full_name}</span>
          <span class="user-role ${roleBadgeClass}">${user.role}</span>
        </div>
        <button id="btn-logout" class="btn-icon" title="Logout" onclick="logoutUser()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
            <polyline points="16 17 21 12 16 7"></polyline>
            <line x1="21" y1="12" x2="9" y2="12"></line>
          </svg>
        </button>
      </div>
    `;

    // Show Admin tab for Admin or Organizer
    if (adminNavItem) {
      if (user.role === 'ADMIN' || user.role === 'ORGANIZER') {
        adminNavItem.style.display = 'inline-flex';
      } else {
        adminNavItem.style.display = 'none';
      }
    }
  } else {
    authNav.innerHTML = `
      <button class="btn btn-outline" onclick="openAuthModal('login')">Sign In</button>
      <button class="btn btn-primary" onclick="openAuthModal('register')">Register</button>
    `;
    if (adminNavItem) adminNavItem.style.display = 'none';
  }
}

function openAuthModal(defaultTab = 'login') {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;
  modal.classList.add('active');
  switchAuthTab(defaultTab);
}

function closeAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (modal) modal.classList.remove('active');
}

function switchAuthTab(tab) {
  const loginForm = document.getElementById('login-form-container');
  const registerForm = document.getElementById('register-form-container');
  const tabLogin = document.getElementById('tab-btn-login');
  const tabRegister = document.getElementById('tab-btn-register');

  if (tab === 'login') {
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
  } else {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
    tabLogin.classList.remove('active');
    tabRegister.classList.add('active');
  }
}

// Quick demo sign-in helper
function quickDemoLogin(type) {
  if (type === 'admin') {
    loginUser('admin@smartevent.com', 'password123');
  } else if (type === 'organizer') {
    loginUser('alex@eventpulse.io', 'password123');
  } else {
    loginUser('aman@gmail.com', 'password123');
  }
}
