// Booking & Ticket Selection Logic

let selectedTickets = {}; // { ticket_id: { quantity, price, name, available } }

function renderTicketTiers(ticketTypes) {
  if (!ticketTypes || ticketTypes.length === 0) {
    return '<p class="empty-text">No tickets currently configured for this event.</p>';
  }

  selectedTickets = {};

  return ticketTypes.map(ticket => {
    const isSoldOut = ticket.available_quantity <= 0;
    const badgeClass = isSoldOut ? 'status-sold-out' : (ticket.available_quantity < 15 ? 'status-low-stock' : 'status-in-stock');
    const badgeText = isSoldOut ? 'Sold Out' : `${ticket.available_quantity} Left`;

    return `
      <div class="ticket-tier-card ${isSoldOut ? 'sold-out' : ''}" id="tier-card-${ticket.ticket_id}">
        <div class="tier-info">
          <div class="tier-header-line">
            <h4 class="tier-name">${ticket.name}</h4>
            <span class="stock-badge ${badgeClass}">${badgeText}</span>
          </div>
          <span class="tier-price">₹${Number(ticket.price).toFixed(2)}</span>
          <span class="tier-subtext">Access pass inclusive of GST</span>
        </div>
        <div class="tier-counter-wrapper">
          <button class="counter-btn" onclick="updateTicketCount(${ticket.ticket_id}, -1)" ${isSoldOut ? 'disabled' : ''}>-</button>
          <span class="counter-value" id="counter-${ticket.ticket_id}">0</span>
          <button class="counter-btn" onclick="updateTicketCount(${ticket.ticket_id}, 1)" ${isSoldOut ? 'disabled' : ''}>+</button>
        </div>
      </div>
    `;
  }).join('');
}

function initTicketCounters(ticketTypes) {
  selectedTickets = {};
  if (!ticketTypes) return;
  ticketTypes.forEach(t => {
    selectedTickets[t.ticket_id] = {
      ticket_id: t.ticket_id,
      name: t.name,
      price: Number(t.price),
      available: t.available_quantity,
      quantity: 0
    };
  });
  updateSelectionSummary();
}

function updateTicketCount(ticketId, delta) {
  if (!selectedTickets[ticketId]) return;

  const current = selectedTickets[ticketId].quantity;
  const maxAvailable = selectedTickets[ticketId].available;
  const next = current + delta;

  if (next < 0) return;
  if (next > maxAvailable) {
    showToast(`Cannot select more than ${maxAvailable} tickets for this tier.`, 'warning');
    return;
  }
  if (next > 10) {
    showToast('Maximum 10 tickets per order limit reached.', 'warning');
    return;
  }

  selectedTickets[ticketId].quantity = next;
  const counterEl = document.getElementById(`counter-${ticketId}`);
  if (counterEl) counterEl.innerText = next;

  updateSelectionSummary();
}

function updateSelectionSummary() {
  let totalQty = 0;
  let totalAmount = 0;

  Object.values(selectedTickets).forEach(t => {
    totalQty += t.quantity;
    totalAmount += t.quantity * t.price;
  });

  const qtyEl = document.getElementById('summary-total-qty');
  const amountEl = document.getElementById('summary-total-amount');
  const btnProceed = document.getElementById('btn-proceed-booking');

  if (qtyEl) qtyEl.innerText = totalQty;
  if (amountEl) amountEl.innerText = `₹${totalAmount.toFixed(2)}`;
  if (btnProceed) {
    btnProceed.disabled = totalQty === 0;
  }
}

function initiateBookingCheckout() {
  const user = getCurrentUser();
  if (!user) {
    showToast('Please sign in to complete your ticket booking', 'info');
    openAuthModal('login');
    return;
  }

  const items = Object.values(selectedTickets)
    .filter(t => t.quantity > 0)
    .map(t => ({
      ticket_id: t.ticket_id,
      name: t.name,
      quantity: t.quantity,
      unit_price: t.price,
      subtotal: t.quantity * t.price
    }));

  if (items.length === 0) {
    showToast('Please select at least 1 ticket.', 'warning');
    return;
  }

  // Open Payment Modal
  openPaymentCheckoutModal({
    event: currentEventDetails,
    items,
    totalAmount: items.reduce((acc, i) => acc + i.subtotal, 0)
  });
}
