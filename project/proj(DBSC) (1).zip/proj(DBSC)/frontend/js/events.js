// Events & Catalog Module

let allEvents = [];
let allCategories = [];
let activeCategoryId = null;
let currentEventDetails = null;

async function loadCategories() {
  try {
    allCategories = await apiRequest('/categories');
    renderCategoryFilters();
  } catch (err) {
    console.error('Failed to load categories', err);
  }
}

function renderCategoryFilters() {
  const container = document.getElementById('category-filter-bar');
  if (!container) return;

  container.innerHTML = `
    <button class="category-chip ${activeCategoryId === null ? 'active' : ''}" onclick="filterByCategory(null)">
      <span>All Events</span>
    </button>
  `;

  allCategories.forEach(cat => {
    const chip = document.createElement('button');
    chip.className = `category-chip ${activeCategoryId === cat.category_id ? 'active' : ''}`;
    chip.onclick = () => filterByCategory(cat.category_id);
    chip.innerHTML = `<span>${cat.name}</span>`;
    container.appendChild(chip);
  });
}

function filterByCategory(categoryId) {
  activeCategoryId = categoryId;
  renderCategoryFilters();
  loadEvents();
}

async function loadEvents() {
  const searchInput = document.getElementById('search-input');
  const search = searchInput ? searchInput.value.trim() : '';

  let endpoint = '/events?status=ACTIVE';
  if (activeCategoryId) endpoint += `&category_id=${activeCategoryId}`;
  if (search) endpoint += `&search=${encodeURIComponent(search)}`;

  const grid = document.getElementById('events-grid');
  if (grid) {
    grid.innerHTML = '<div class="loading-spinner"><div class="spinner"></div><p>Discovering upcoming events...</p></div>';
  }

  try {
    allEvents = await apiRequest(endpoint);
    renderEventsGrid(allEvents);
  } catch (err) {
    if (grid) {
      grid.innerHTML = `
        <div class="empty-state">
          <p class="error-msg">Could not load events: ${err.message}</p>
          <button class="btn btn-primary" onclick="loadEvents()">Try Again</button>
        </div>
      `;
    }
  }
}

function renderEventsGrid(events) {
  const grid = document.getElementById('events-grid');
  if (!grid) return;

  if (!events || events.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="8" y1="12" x2="16" y2="12"></line>
        </svg>
        <h3>No Events Found</h3>
        <p>Try clearing search keywords or selecting another category.</p>
        <button class="btn btn-outline" onclick="resetFilters()">View All Events</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = events.map(evt => {
    // Calculate starting price
    let minPrice = 'Free';
    if (evt.ticket_types && evt.ticket_types.length > 0) {
      const prices = evt.ticket_types.map(t => Number(t.price));
      minPrice = `₹${Math.min(...prices)}`;
    }

    const eventDate = new Date(evt.event_date);
    const dateFormatted = eventDate.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });

    const categoryName = evt.category ? evt.category.name : 'Event';
    const venueName = evt.venue ? `${evt.venue.name}, ${evt.venue.city}` : 'Venue TBA';
    const banner = evt.banner_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800';

    return `
      <div class="event-card animate-fade-in" onclick="openEventDetails(${evt.event_id})">
        <div class="card-banner-wrapper">
          <img src="${banner}" alt="${evt.title}" class="card-banner" loading="lazy" />
          <span class="category-tag">${categoryName}</span>
          <div class="date-badge">
            <span class="date-month">${eventDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}</span>
            <span class="date-day">${eventDate.getDate()}</span>
          </div>
        </div>
        <div class="card-content">
          <h3 class="event-title">${evt.title}</h3>
          <div class="event-meta-row">
            <span class="meta-item">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              ${venueName}
            </span>
          </div>
          <div class="event-meta-row">
            <span class="meta-item">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
              </svg>
              ${evt.start_time.slice(0, 5)} - ${evt.end_time.slice(0, 5)}
            </span>
          </div>
          <div class="card-footer">
            <div class="price-box">
              <span class="price-label">Starting from</span>
              <span class="price-amount">${minPrice}</span>
            </div>
            <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); openEventDetails(${evt.event_id})">
              Book Tickets
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function resetFilters() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = '';
  activeCategoryId = null;
  renderCategoryFilters();
  loadEvents();
}

async function openEventDetails(eventId) {
  const modal = document.getElementById('event-detail-modal');
  if (!modal) return;

  const content = document.getElementById('event-detail-content');
  content.innerHTML = '<div class="loading-spinner"><div class="spinner"></div><p>Loading details...</p></div>';
  modal.classList.add('active');

  try {
    const event = await apiRequest(`/events/${eventId}`);
    currentEventDetails = event;

    // Fetch reviews
    const reviews = await apiRequest(`/reviews/event/${eventId}`).catch(() => []);

    const eventDate = new Date(event.event_date);
    const dateFormatted = eventDate.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // Compute average rating
    let avgRating = 'No reviews yet';
    if (reviews.length > 0) {
      const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
      avgRating = `★ ${(sum / reviews.length).toFixed(1)} (${reviews.length} reviews)`;
    }

    content.innerHTML = `
      <div class="detail-header">
        <img src="${event.banner_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200'}" class="detail-banner" alt="${event.title}" />
        <div class="detail-header-overlay">
          <span class="category-tag">${event.category ? event.category.name : 'Event'}</span>
          <h2>${event.title}</h2>
          <div class="rating-badge">${avgRating}</div>
        </div>
      </div>

      <div class="detail-body">
        <div class="detail-info-grid">
          <div class="info-block">
            <span class="info-label">Date & Time</span>
            <span class="info-value">${dateFormatted}</span>
            <span class="info-sub">${event.start_time} to ${event.end_time}</span>
          </div>
          <div class="info-block">
            <span class="info-label">Venue</span>
            <span class="info-value">${event.venue ? event.venue.name : 'Venue'}</span>
            <span class="info-sub">${event.venue ? `${event.venue.address}, ${event.venue.city}` : ''}</span>
          </div>
          <div class="info-block">
            <span class="info-label">Capacity</span>
            <span class="info-value">${event.venue ? event.venue.capacity.toLocaleString() : 'N/A'} Guests</span>
            <span class="info-sub">Organized by verified host</span>
          </div>
        </div>

        <div class="section-divider"></div>

        <div class="event-description-section">
          <h3>About this Event</h3>
          <p>${event.description || 'No description provided for this event.'}</p>
        </div>

        <div class="section-divider"></div>

        <div class="tickets-selection-section">
          <div class="section-title-row">
            <h3>Select Tickets</h3>
            <span class="live-indicator"><span class="dot"></span> Live Ticket Availability</span>
          </div>
          <div id="ticket-tiers-container" class="ticket-tiers-container">
            ${renderTicketTiers(event.ticket_types)}
          </div>
          <div class="ticket-selection-summary" id="ticket-selection-summary">
            <div class="summary-details">
              <span>Total Selected: <strong id="summary-total-qty">0</strong> tickets</span>
              <span class="summary-price">Amount: <strong id="summary-total-amount">₹0.00</strong></span>
            </div>
            <button id="btn-proceed-booking" class="btn btn-primary btn-lg" onclick="initiateBookingCheckout()" disabled>
              Proceed to Checkout
            </button>
          </div>
        </div>

        <div class="section-divider"></div>

        <div class="reviews-section">
          <div class="section-title-row">
            <h3>Community Reviews</h3>
            <button class="btn btn-outline btn-sm" onclick="openReviewModal(${event.event_id})">Write a Review</button>
          </div>
          <div class="reviews-list">
            ${reviews.length > 0 ? reviews.map(r => `
              <div class="review-card">
                <div class="review-header">
                  <span class="reviewer-name">${r.user ? r.user.full_name : 'Attendee'}</span>
                  <span class="review-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
                </div>
                <p class="review-comment">${r.comment || 'No comment provided.'}</p>
                <span class="review-date">${new Date(r.created_at).toLocaleDateString()}</span>
              </div>
            `).join('') : '<p class="empty-text">Be the first to review this event!</p>'}
          </div>
        </div>
      </div>
    `;

    initTicketCounters(event.ticket_types);
  } catch (err) {
    content.innerHTML = `<div class="empty-state"><p class="error-msg">Error loading event details: ${err.message}</p></div>`;
  }
}

function closeEventDetails() {
  const modal = document.getElementById('event-detail-modal');
  if (modal) modal.classList.remove('active');
  currentEventDetails = null;
}
