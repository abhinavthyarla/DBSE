// User Booking History & Reviews Module

let userBookings = [];
let reviewTargetEventId = null;
let currentRating = 5;

async function loadMyBookings() {
  const user = getCurrentUser();
  const container = document.getElementById('my-bookings-list');
  if (!container) return;

  if (!user) {
    container.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="12" y1="8" x2="12" y2="12"></line>
          <line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <h3>Sign In Required</h3>
        <p>Please log in to view your past tickets and booking history.</p>
        <button class="btn btn-primary" onclick="openAuthModal('login')">Sign In Now</button>
      </div>
    `;
    return;
  }

  container.innerHTML = '<div class="loading-spinner"><div class="spinner"></div><p>Loading your bookings...</p></div>';

  try {
    userBookings = await apiRequest('/bookings/my');
    renderMyBookings(userBookings);
  } catch (err) {
    container.innerHTML = `<div class="empty-state"><p class="error-msg">Error loading bookings: ${err.message}</p></div>`;
  }
}

function renderMyBookings(bookings) {
  const container = document.getElementById('my-bookings-list');
  if (!container) return;

  if (!bookings || bookings.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="16" y1="2" x2="16" y2="6"></line>
          <line x1="8" y1="2" x2="8" y2="6"></line>
          <line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
        <h3>No Bookings Yet</h3>
        <p>You haven't reserved any event tickets yet.</p>
        <button class="btn btn-primary" onclick="switchTab('events')">Browse Events</button>
      </div>
    `;
    return;
  }

  container.innerHTML = bookings.map(b => {
    const bookingDate = new Date(b.booking_date).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    const isConfirmed = b.booking_status === 'CONFIRMED';
    const statusBadgeClass = isConfirmed ? 'status-confirmed' : 'status-cancelled';

    return `
      <div class="booking-history-card animate-fade-in">
        <div class="booking-card-header">
          <div class="booking-ref-box">
            <span class="booking-ref-title">Order Reference</span>
            <span class="booking-ref-code">${b.booking_ref}</span>
          </div>
          <div class="booking-date-status">
            <span class="booking-timestamp">${bookingDate}</span>
            <span class="status-badge ${statusBadgeClass}">${b.booking_status}</span>
          </div>
        </div>

        <div class="booking-card-items">
          ${b.details.map(d => `
            <div class="booking-item-line">
              <span class="item-name">${d.ticket_type ? d.ticket_type.name : 'Ticket Tier'}</span>
              <span class="item-qty">Qty: ${d.quantity}</span>
              <span class="item-price">₹${Number(d.subtotal).toFixed(2)}</span>
            </div>
          `).join('')}
        </div>

        <div class="booking-card-footer">
          <div class="total-paid">
            <span>Total:</span>
            <strong>₹${Number(b.total_amount).toFixed(2)}</strong>
          </div>
          <div class="card-actions">
            ${isConfirmed ? `
              <button class="btn btn-danger-outline btn-sm" onclick="cancelUserBooking(${b.booking_id})">
                Cancel Booking
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

async function cancelUserBooking(bookingId) {
  if (!confirm('Are you sure you want to cancel this booking? Tickets will be returned to the available pool.')) {
    return;
  }

  try {
    await apiRequest(`/bookings/${bookingId}/cancel`, { method: 'POST' });
    showToast('Booking cancelled successfully and ticket quantities restored.', 'success');
    loadMyBookings();
    if (typeof loadEvents === 'function') loadEvents();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Review Modal Functions
function openReviewModal(eventId) {
  const user = getCurrentUser();
  if (!user) {
    showToast('Please sign in to post a review', 'info');
    openAuthModal('login');
    return;
  }

  reviewTargetEventId = eventId;
  currentRating = 5;
  updateStarDisplay(5);

  const modal = document.getElementById('review-modal');
  const commentInput = document.getElementById('review-comment-input');
  if (commentInput) commentInput.value = '';
  if (modal) modal.classList.add('active');
}

function closeReviewModal() {
  const modal = document.getElementById('review-modal');
  if (modal) modal.classList.remove('active');
  reviewTargetEventId = null;
}

function setReviewRating(rating) {
  currentRating = rating;
  updateStarDisplay(rating);
}

function updateStarDisplay(rating) {
  const stars = document.querySelectorAll('.star-rating-btn');
  stars.forEach((s, idx) => {
    if (idx < rating) {
      s.classList.add('selected');
    } else {
      s.classList.remove('selected');
    }
  });
}

async function submitEventReview() {
  if (!reviewTargetEventId) return;

  const commentInput = document.getElementById('review-comment-input');
  const comment = commentInput ? commentInput.value.trim() : '';

  try {
    await apiRequest('/reviews', {
      method: 'POST',
      body: JSON.stringify({
        event_id: reviewTargetEventId,
        rating: currentRating,
        comment: comment
      })
    });

    showToast('Review submitted successfully! Thank you.', 'success');
    closeReviewModal();
    if (typeof openEventDetails === 'function') {
      openEventDetails(reviewTargetEventId);
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}
