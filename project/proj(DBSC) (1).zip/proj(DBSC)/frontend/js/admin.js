// Admin Dashboard & Database Reports Module

async function loadAdminDashboard() {
  const user = getCurrentUser();
  if (!user || (user.role !== 'ADMIN' && user.role !== 'ORGANIZER')) {
    showToast('Admin or Organizer access required', 'error');
    switchTab('events');
    return;
  }

  loadMetrics();
  loadAdminEvents();
  loadAdminReports();
}

async function loadMetrics() {
  try {
    const data = await apiRequest('/admin/metrics');
    document.getElementById('metric-revenue').innerText = `₹${Number(data.total_revenue).toLocaleString()}`;
    document.getElementById('metric-bookings').innerText = data.total_bookings.toLocaleString();
    document.getElementById('metric-events').innerText = data.total_events.toLocaleString();
    document.getElementById('metric-users').innerText = data.total_users.toLocaleString();
  } catch (err) {
    console.error('Failed to load admin metrics', err);
  }
}

async function loadAdminEvents() {
  const container = document.getElementById('admin-events-tbody');
  if (!container) return;

  container.innerHTML = '<tr><td colspan="6" class="text-center py-4">Loading events...</td></tr>';

  try {
    const events = await apiRequest('/events?status=ALL');
    if (!events || events.length === 0) {
      container.innerHTML = '<tr><td colspan="6" class="text-center py-4">No events found.</td></tr>';
      return;
    }

    container.innerHTML = events.map(evt => {
      const ticketsCount = evt.ticket_types ? evt.ticket_types.reduce((acc, t) => acc + t.total_quantity, 0) : 0;
      const availCount = evt.ticket_types ? evt.ticket_types.reduce((acc, t) => acc + t.available_quantity, 0) : 0;
      return `
        <tr>
          <td><strong>#${evt.event_id}</strong></td>
          <td>
            <div class="admin-table-title">${evt.title}</div>
            <small class="text-muted">${evt.category ? evt.category.name : ''}</small>
          </td>
          <td>${evt.event_date}</td>
          <td>${evt.venue ? evt.venue.city : ''}</td>
          <td>
            <span class="stock-pill">${availCount} / ${ticketsCount}</span>
          </td>
          <td>
            <div class="table-actions">
              <button class="btn-icon" title="View details" onclick="openEventDetails(${evt.event_id})">👁</button>
              <button class="btn-icon btn-icon-danger" title="Delete event" onclick="deleteAdminEvent(${evt.event_id})">🗑</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

async function deleteAdminEvent(eventId) {
  if (!confirm('Are you sure you want to delete this event? All associated bookings and ticket types will be removed.')) {
    return;
  }
  try {
    await apiRequest(`/events/${eventId}`, { method: 'DELETE' });
    showToast('Event deleted successfully', 'success');
    loadAdminEvents();
    loadMetrics();
    if (typeof loadEvents === 'function') loadEvents();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function loadAdminReports() {
  const salesTbody = document.getElementById('report-sales-tbody');
  const popularTbody = document.getElementById('report-popular-tbody');
  const chartContainer = document.getElementById('admin-sales-chart');

  try {
    const salesData = await apiRequest('/admin/reports/sales');

    // Render sales chart
    if (chartContainer && salesData.length > 0) {
      const maxRev = Math.max(...salesData.map(d => d.revenue), 1000);
      chartContainer.innerHTML = salesData.map(d => {
        const pct = Math.min(100, Math.round((d.revenue / maxRev) * 100));
        return `
          <div class="chart-bar-row">
            <div class="chart-label" title="${d.title}">${d.title.length > 25 ? d.title.slice(0, 22) + '...' : d.title}</div>
            <div class="chart-bar-wrapper">
              <div class="chart-bar-fill" style="width: ${pct}%;"></div>
            </div>
            <div class="chart-value">₹${d.revenue.toLocaleString()}</div>
          </div>
        `;
      }).join('');
    }

    // Render sales report table
    if (salesTbody) {
      salesTbody.innerHTML = salesData.map(s => `
        <tr>
          <td><strong>${s.title}</strong></td>
          <td>${s.category}</td>
          <td>${s.venue}</td>
          <td>${s.event_date}</td>
          <td><span class="badge-qty">${s.tickets_sold}</span></td>
          <td><strong>₹${Number(s.revenue).toFixed(2)}</strong></td>
        </tr>
      `).join('');
    }

    // Render popular events report table
    const popularData = await apiRequest('/admin/reports/popular');
    if (popularTbody) {
      popularTbody.innerHTML = popularData.map((p, idx) => `
        <tr>
          <td>#${idx + 1}</td>
          <td><strong>${p.title}</strong></td>
          <td>${p.category}</td>
          <td>${p.total_orders} Orders</td>
          <td>★ ${p.avg_rating} (${p.reviews_count})</td>
        </tr>
      `).join('');
    }
  } catch (err) {
    console.error('Failed to load database reports', err);
  }
}

// Create New Event Modal Functions
async function openCreateEventModal() {
  const modal = document.getElementById('create-event-modal');
  if (!modal) return;

  // Populate Categories dropdown
  const catSelect = document.getElementById('create-event-category');
  if (catSelect) {
    catSelect.innerHTML = allCategories.map(c => `<option value="${c.category_id}">${c.name}</option>`).join('');
  }

  // Populate Venues dropdown
  try {
    const venues = await apiRequest('/venues');
    const venueSelect = document.getElementById('create-event-venue');
    if (venueSelect) {
      venueSelect.innerHTML = venues.map(v => `<option value="${v.venue_id}">${v.name} (${v.city})</option>`).join('');
    }
  } catch (e) {
    console.error(e);
  }

  modal.classList.add('active');
}

function closeCreateEventModal() {
  const modal = document.getElementById('create-event-modal');
  if (modal) modal.classList.remove('active');
}

async function submitCreateEvent() {
  const title = document.getElementById('create-event-title').value.trim();
  const description = document.getElementById('create-event-desc').value.trim();
  const category_id = parseInt(document.getElementById('create-event-category').value);
  const venue_id = parseInt(document.getElementById('create-event-venue').value);
  const event_date = document.getElementById('create-event-date').value;
  const start_time = document.getElementById('create-event-start').value;
  const end_time = document.getElementById('create-event-end').value;
  const banner_url = document.getElementById('create-event-banner').value.trim() || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200';

  if (!title || !event_date || !start_time || !end_time) {
    showToast('Please fill in all required event details', 'warning');
    return;
  }

  try {
    await apiRequest('/events', {
      method: 'POST',
      body: JSON.stringify({
        title,
        description,
        category_id,
        venue_id,
        banner_url,
        event_date,
        start_time: start_time + ':00',
        end_time: end_time + ':00',
        status: 'ACTIVE'
      })
    });

    showToast('Event created successfully with default ticket tiers!', 'success');
    closeCreateEventModal();
    loadAdminEvents();
    loadMetrics();
    if (typeof loadEvents === 'function') loadEvents();
  } catch (err) {
    showToast(err.message, 'error');
  }
}
