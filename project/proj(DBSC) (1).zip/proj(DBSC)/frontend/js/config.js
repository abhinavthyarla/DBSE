// Configuration settings for the Smart Event Frontend
const CONFIG = {
  // If served directly through FastAPI backend (port 8000), use '/api'
  // If served via live server or file protocol, point to localhost:8000/api
  API_BASE_URL: window.location.origin.includes(':8000') 
    ? `${window.location.origin}/api` 
    : 'http://localhost:8000/api',
  STORAGE_KEYS: {
    TOKEN: 'smartevent_jwt_token',
    USER: 'smartevent_user_profile',
    THEME: 'smartevent_theme'
  }
};
