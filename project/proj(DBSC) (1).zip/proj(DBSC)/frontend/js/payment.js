// Payment Simulation & Booking Confirmation Module

let currentCheckoutData = null;
let activePaymentMethod = 'UPI';

function openPaymentCheckoutModal(checkoutData) {
  currentCheckoutData = checkoutData;
  const modal = document.getElementById('payment-modal');
  if (!modal) return;

  // Render Order Summary
  const summaryContainer = document.getElementById('checkout-order-summary');
  if (summaryContainer) {
    summaryContainer.innerHTML = `
      <div class="checkout-event-title">${checkoutData.event.title}</div>
      <div class="checkout-items-list">
        ${checkoutData.items.map(item => `
          <div class="checkout-item-row">
            <span>${item.name} × ${item.quantity}</span>
            <span>₹${item.subtotal.toFixed(2)}</span>
          </div>
        `).join('')}
      </div>
      <div class="checkout-total-row">
        <span>Total Payable:</span>
        <strong class="total-amount-highlight">₹${checkoutData.totalAmount.toFixed(2)}</strong>
      </div>
    `;
  }

  // Set Pay Button text
  const payBtn = document.getElementById('btn-confirm-payment');
  if (payBtn) {
    payBtn.innerText = `Pay ₹${checkoutData.totalAmount.toFixed(2)} & Confirm`;
    payBtn.disabled = false;
  }

  modal.classList.add('active');
  selectPaymentMethod('UPI');
}

function closePaymentModal() {
  const modal = document.getElementById('payment-modal');
  if (modal) modal.classList.remove('active');
  currentCheckoutData = null;
}

function selectPaymentMethod(method) {
  activePaymentMethod = method;

  const tabs = document.querySelectorAll('.payment-tab-btn');
  tabs.forEach(t => t.classList.remove('active'));

  const activeTab = document.getElementById(`pay-tab-${method.toLowerCase()}`);
  if (activeTab) activeTab.classList.add('active');

  const upiSection = document.getElementById('pay-section-upi');
  const cardSection = document.getElementById('pay-section-card');
  const netbankSection = document.getElementById('pay-section-netbank');

  if (upiSection) upiSection.style.display = method === 'UPI' ? 'block' : 'none';
  if (cardSection) cardSection.style.display = method === 'CARD' ? 'block' : 'none';
  if (netbankSection) netbankSection.style.display = method === 'NETBANKING' ? 'block' : 'none';
}

async function processPaymentSimulation() {
  if (!currentCheckoutData) return;

  const simulateFailureCheckbox = document.getElementById('simulate-failure-checkbox');
  const shouldFail = simulateFailureCheckbox ? simulateFailureCheckbox.checked : false;

  const payBtn = document.getElementById('btn-confirm-payment');
  if (payBtn) {
    payBtn.disabled = true;
    payBtn.innerHTML = '<span class="spinner-sm"></span> Processing Payment...';
  }

  try {
    if (shouldFail) {
      await new Promise(r => setTimeout(r, 1200));
      throw new Error('Simulated Payment Gateway Error: Bank server declined the transaction (Demonstration of Rollback)');
    }

    // Call Transactional Booking API
    const bookingPayload = {
      items: currentCheckoutData.items.map(i => ({
        ticket_id: i.ticket_id,
        quantity: i.quantity
      })),
      payment_method: activePaymentMethod
    };

    const bookingResult = await apiRequest('/bookings', {
      method: 'POST',
      body: JSON.stringify(bookingPayload)
    });

    closePaymentModal();
    closeEventDetails();
    displayBookingConfirmation(bookingResult, currentCheckoutData.event);
    showToast('Booking and Payment Confirmed Successfully!', 'success');

    // Refresh event catalog & my bookings
    if (typeof loadEvents === 'function') loadEvents();
    if (typeof loadMyBookings === 'function') loadMyBookings();

  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    if (payBtn) {
      payBtn.disabled = false;
      payBtn.innerText = currentCheckoutData ? `Pay ₹${currentCheckoutData.totalAmount.toFixed(2)} & Confirm` : 'Pay';
    }
  }
}

function displayBookingConfirmation(booking, event) {
  const modal = document.getElementById('confirmation-modal');
  if (!modal) return;

  const content = document.getElementById('confirmation-modal-content');
  const eventDate = new Date(event.event_date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });

  content.innerHTML = `
    <div class="confirmation-ticket-pass animate-scale-up">
      <div class="pass-header">
        <div class="success-icon-badge">✓</div>
        <h2>Booking Confirmed!</h2>
        <p class="pass-sub">Your digital ticket pass has been generated</p>
      </div>

      <div class="pass-body">
        <div class="pass-meta-row">
          <div class="pass-meta-col">
            <span class="meta-label">Booking Reference</span>
            <span class="meta-val highlight-ref">${booking.booking_ref}</span>
          </div>
          <div class="pass-meta-col text-right">
            <span class="meta-label">Status</span>
            <span class="meta-val status-confirmed">CONFIRMED</span>
          </div>
        </div>

        <div class="pass-divider"></div>

        <div class="pass-event-info">
          <h3>${event.title}</h3>
          <p class="pass-venue">📍 ${event.venue ? `${event.venue.name}, ${event.venue.city}` : 'Venue'}</p>
          <p class="pass-datetime">📅 ${eventDate} | ⏰ ${event.start_time.slice(0, 5)}</p>
        </div>

        <div class="pass-divider"></div>

        <div class="pass-details-list">
          ${booking.details.map(d => `
            <div class="pass-item">
              <span>${d.ticket_type ? d.ticket_type.name : 'Ticket'} × ${d.quantity}</span>
              <span>₹${Number(d.subtotal).toFixed(2)}</span>
            </div>
          `).join('')}
          <div class="pass-item pass-total">
            <strong>Total Paid</strong>
            <strong>₹${Number(booking.total_amount).toFixed(2)}</strong>
          </div>
        </div>

        <div class="pass-qr-section">
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${booking.booking_ref}" alt="Ticket QR Code" class="pass-qr" />
          <span class="qr-caption">Scan at the venue entrance for instant admission</span>
        </div>
      </div>

      <div class="pass-footer">
        <button class="btn btn-outline" onclick="window.print()">Print / Save Pass</button>
        <button class="btn btn-primary" onclick="closeConfirmationModal(); switchTab('history');">View My Bookings</button>
      </div>
    </div>
  `;

  modal.classList.add('active');
}

function closeConfirmationModal() {
  const modal = document.getElementById('confirmation-modal');
  if (modal) modal.classList.remove('active');
}
