// Main Application Entry Point & Navigation Controller

let deferredPrompt = null;

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initServiceWorker();
  initPWAInstall();
  updateAuthUI();
  loadCategories();
  loadEvents();

  // Bind Search input with debounce
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        loadEvents();
      }, 350);
    });
  }

  // Bind Auth Modal forms
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      await loginUser(email, password);
    });
  }

  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fullName = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const password = document.getElementById('reg-password').value;
      const phone = document.getElementById('reg-phone').value.trim();
      const role = document.getElementById('reg-role').value;
      await registerUser(fullName, email, password, phone, role);
    });
  }
});

// Tab Navigation
function switchTab(tabName) {
  // Hide all view sections
  document.querySelectorAll('.app-view').forEach(view => {
    view.style.display = 'none';
  });

  // Deactivate all nav links
  document.querySelectorAll('.nav-link, .bottom-nav-item').forEach(link => {
    link.classList.remove('active');
  });

  // Activate selected view
  const targetView = document.getElementById(`view-${tabName}`);
  if (targetView) targetView.style.display = 'block';

  // Activate nav elements
  const topNav = document.getElementById(`nav-${tabName}`);
  const btmNav = document.getElementById(`bnav-${tabName}`);
  if (topNav) topNav.classList.add('active');
  if (btmNav) btmNav.classList.add('active');

  // Trigger loads based on tab
  if (tabName === 'history') {
    loadMyBookings();
  } else if (tabName === 'admin') {
    loadAdminDashboard();
  } else if (tabName === 'events') {
    loadEvents();
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Theme Toggle
function initTheme() {
  const saved = localStorage.getItem(CONFIG.STORAGE_KEYS.THEME) || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem(CONFIG.STORAGE_KEYS.THEME, next);
  updateThemeIcon(next);
}

function updateThemeIcon(theme) {
  const icon = document.getElementById('theme-toggle-icon');
  if (icon) {
    icon.innerHTML = theme === 'dark' 
      ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>'
      : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
  }
}

// Service Worker for Android PWA
function initServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(err => {
        console.log('ServiceWorker registration error:', err);
      });
    });
  }
}

// Android PWA Installation Banner
function initPWAInstall() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const installBanner = document.getElementById('pwa-install-banner');
    if (installBanner) installBanner.style.display = 'flex';
  });

  const installBtn = document.getElementById('btn-pwa-install');
  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          showToast('Smart Event App installed to your device!', 'success');
        }
        deferredPrompt = null;
        const banner = document.getElementById('pwa-install-banner');
        if (banner) banner.style.display = 'none';
      }
    });
  }
}
